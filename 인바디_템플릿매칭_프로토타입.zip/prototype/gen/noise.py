# -*- coding: utf-8 -*-
"""
촬영 노이즈 증강.

적용 순서가 중요하다 — 실제 촬영에서 일어나는 순서를 따른다:
  ① 종이 자체의 상태 : 접힘 / 구김 / 얼룩
  ② 종이에 떨어지는 빛: 그림자 / 조명 불균일 / 반사광
  ③ 카메라 기하       : 원근 / 기울기
  ④ 배경 위 합성      : 책상에 놓인 종이
  ⑤ 센서·렌즈         : 블러 / 저해상도 / 그레인 / 색온도 / JPEG
"""
import io
import numpy as np
import cv2
from PIL import Image


# ------------------------------------------------------------------ 유틸
def _f(img):
    return img.astype(np.float32)


def _u8(a):
    return np.clip(a, 0, 255).astype(np.uint8)


def _smooth_noise(h, w, scale, rnd):
    """저주파 노이즈 필드 (0~1)."""
    sh, sw = max(2, int(h / scale)), max(2, int(w / scale))
    n = rnd.random((sh, sw)).astype(np.float32)
    n = cv2.resize(n, (w, h), interpolation=cv2.INTER_CUBIC)
    return np.clip(n, 0, 1)


# ------------------------------------------------------- ① 종이 상태
def fold(rgb, rnd, n_lines=1, depth=0.22):
    """접힘 자국 — 밝기 불연속 + 접힌 선 주변 미세 변위."""
    h, w = rgb.shape[:2]
    out = _f(rgb)
    for _ in range(n_lines):
        horiz = rnd.random() < 0.6
        if horiz:
            pos = int(rnd.uniform(0.25, 0.75) * h)
            band = np.exp(-((np.arange(h) - pos) ** 2) / (2 * (h * 0.012) ** 2))
            m = band[:, None]
            edge = (np.arange(h) > pos)[:, None].astype(np.float32)
        else:
            pos = int(rnd.uniform(0.25, 0.75) * w)
            band = np.exp(-((np.arange(w) - pos) ** 2) / (2 * (w * 0.012) ** 2))
            m = band[None, :]
            edge = (np.arange(w) > pos)[None, :].astype(np.float32)
        shade = 1.0 - depth * m + depth * 0.45 * m * edge      # 한쪽은 그늘, 한쪽은 하이라이트
        out *= shade[..., None] if out.ndim == 3 else shade
        # 접힌 면의 미세한 밝기 차 (종이가 완전히 평평하지 않음)
        out *= (1.0 - 0.035 * edge)[..., None]
    return _u8(out)


def crumple(rgb, rnd, amp=0.13):
    """구김 — 저주파 명암 얼룩."""
    h, w = rgb.shape[:2]
    n = _smooth_noise(h, w, rnd.uniform(28, 70), rnd)
    return _u8(_f(rgb) * (1.0 - amp / 2 + amp * n)[..., None])


# --------------------------------------------------------- ② 빛
def shadow(rgb, rnd, strength=0.42):
    """손·기기가 만드는 방향성 그림자."""
    h, w = rgb.shape[:2]
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    ang = rnd.uniform(0, np.pi)
    d = np.cos(ang) * (xx / w - rnd.uniform(0.15, 0.85)) + \
        np.sin(ang) * (yy / h - rnd.uniform(0.15, 0.85))
    edge = rnd.uniform(0.05, 0.30)
    m = 1 / (1 + np.exp(-d / edge))
    if rnd.random() < 0.5:
        m = 1 - m
    return _u8(_f(rgb) * (1 - strength * m)[..., None])


def illumination(rgb, rnd, vig=0.30, grad=0.20):
    """비네팅 + 한쪽으로 기운 조명."""
    h, w = rgb.shape[:2]
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    cx, cy = rnd.uniform(0.3, 0.7) * w, rnd.uniform(0.3, 0.7) * h
    r = np.sqrt(((xx - cx) / w) ** 2 + ((yy - cy) / h) ** 2)
    v = 1 - vig * (r / (r.max() + 1e-6)) ** 1.8
    g = 1 - grad * (rnd.random() * (xx / w) + (1 - rnd.random()) * (yy / h)) / 2
    return _u8(_f(rgb) * (v * g)[..., None])


def glare(rgb, rnd, strength=0.55):
    """형광등 반사광."""
    h, w = rgb.shape[:2]
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    cx, cy = rnd.uniform(0.1, 0.9) * w, rnd.uniform(0.1, 0.9) * h
    sx, sy = rnd.uniform(0.06, 0.22) * w, rnd.uniform(0.03, 0.13) * h
    th = rnd.uniform(0, np.pi)
    X = (xx - cx) * np.cos(th) + (yy - cy) * np.sin(th)
    Y = -(xx - cx) * np.sin(th) + (yy - cy) * np.cos(th)
    m = np.exp(-((X / sx) ** 2 + (Y / sy) ** 2))
    out = _f(rgb) + strength * 255 * m[..., None]
    return _u8(out)


# ---------------------------------------------------- ③ 기하 (RGBA)
def to_rgba(rgb):
    a = np.full(rgb.shape[:2] + (1,), 255, np.uint8)
    return np.concatenate([rgb, a], axis=2)


def geom(rgba, rnd, rot=0.0, persp=0.0, pad=0.10):
    """회전 + 원근 왜곡. 캔버스를 넓혀 잘림을 막는다."""
    h, w = rgba.shape[:2]
    py, px = int(h * pad), int(w * pad)
    canv = cv2.copyMakeBorder(rgba, py, py, px, px, cv2.BORDER_CONSTANT, value=(0, 0, 0, 0))
    H, W = canv.shape[:2]

    M = cv2.getRotationMatrix2D((W / 2, H / 2), rnd.uniform(-rot, rot), 1.0)
    canv = cv2.warpAffine(canv, M, (W, H), flags=cv2.INTER_LINEAR,
                          borderMode=cv2.BORDER_CONSTANT, borderValue=(0, 0, 0, 0))
    if persp > 0:
        m = persp * min(H, W)
        src = np.float32([[0, 0], [W, 0], [W, H], [0, H]])
        dst = src + np.float32([[rnd.uniform(-m, m), rnd.uniform(-m, m)] for _ in range(4)])
        P = cv2.getPerspectiveTransform(src, dst)
        canv = cv2.warpPerspective(canv, P, (W, H), flags=cv2.INTER_LINEAR,
                                   borderMode=cv2.BORDER_CONSTANT, borderValue=(0, 0, 0, 0))
    return canv


# --------------------------------------------------- ④ 배경 합성
def make_background(h, w, rnd):
    """책상 표면 — 나무결 / 무채색 / 패브릭."""
    kind = rnd.choice(["wood", "gray", "fabric"])
    base = _smooth_noise(h, w, rnd.uniform(40, 120), rnd)
    if kind == "wood":
        col = np.array([rnd.uniform(96, 150), rnd.uniform(66, 108), rnd.uniform(40, 72)])
        grain = _smooth_noise(h, w, 6, rnd)
        f = base * 0.75 + grain * 0.25
    elif kind == "gray":
        col = np.array([rnd.uniform(120, 190)] * 3)
        f = base
    else:
        col = np.array([rnd.uniform(70, 130), rnd.uniform(75, 135), rnd.uniform(85, 145)])
        f = base * 0.6 + _smooth_noise(h, w, 3, rnd) * 0.4
    bg = col[None, None, :] * (0.72 + 0.5 * f[..., None])
    return _u8(bg)


def composite(rgba, rnd, use_bg=True):
    h, w = rgba.shape[:2]
    rgb = _f(rgba[..., :3])
    a = _f(rgba[..., 3:]) / 255.0
    if use_bg:
        bg = _f(make_background(h, w, rnd))
        # 종이 아래 드롭섀도
        sh = cv2.GaussianBlur(a[..., 0], (0, 0), max(h, w) * 0.012)
        off = int(max(h, w) * 0.006)
        sh = np.roll(np.roll(sh, off, axis=0), off, axis=1)
        bg *= (1 - 0.45 * np.clip(sh - a[..., 0], 0, 1))[..., None]
    else:
        bg = np.full_like(rgb, 255.0)
    return _u8(rgb * a + bg * (1 - a))


# ------------------------------------------------- ⑤ 센서·렌즈
def motion_blur(rgb, rnd, k=9):
    k = max(3, int(k) | 1)
    ker = np.zeros((k, k), np.float32)
    th = rnd.uniform(0, np.pi)
    c = k // 2
    for i in range(k):
        x = int(round(c + (i - c) * np.cos(th)))
        y = int(round(c + (i - c) * np.sin(th)))
        if 0 <= x < k and 0 <= y < k:
            ker[y, x] = 1
    ker /= ker.sum()
    return cv2.filter2D(rgb, -1, ker)


def defocus(rgb, sigma):
    return cv2.GaussianBlur(rgb, (0, 0), sigma) if sigma > 0.05 else rgb


def lowres(rgb, factor):
    h, w = rgb.shape[:2]
    sh, sw = max(60, int(h / factor)), max(60, int(w / factor))
    small = cv2.resize(rgb, (sw, sh), interpolation=cv2.INTER_AREA)
    return cv2.resize(small, (w, h), interpolation=cv2.INTER_LINEAR)


def grain(rgb, rnd, sigma=6.0):
    n = rnd.normal(0, sigma, rgb.shape).astype(np.float32)
    return _u8(_f(rgb) + n)


def color_cast(rgb, rnd, amp=0.10):
    g = np.array([1 + rnd.uniform(-amp, amp), 1 + rnd.uniform(-amp * 0.5, amp * 0.5),
                  1 + rnd.uniform(-amp, amp)], np.float32)
    return _u8(_f(rgb) * g[None, None, :])


def auto_exposure(rgb, target=222.0, lo=0.80, hi=2.60):
    """
    휴대폰 카메라의 자동 노출을 흉내낸다.
    그림자·비네팅·반사광을 곱하면 전체가 어두워지는데, 실제 카메라는
    이를 보정해서 종이가 대략 일정한 밝기로 찍힌다. 이 단계가 없으면
    합성 이미지만 비정상적으로 어두워져 OCR 난이도가 왜곡된다.
    """
    lum = rgb.astype(np.float32) @ np.array([0.299, 0.587, 0.114], np.float32)
    p = np.percentile(lum, 92)
    if p < 1:
        return rgb
    g = float(np.clip(target / p, lo, hi))
    return _u8(_f(rgb) * g)


def jpeg(rgb, q):
    buf = io.BytesIO()
    Image.fromarray(rgb).save(buf, "JPEG", quality=int(q))
    buf.seek(0)
    return np.array(Image.open(buf).convert("RGB"))


# ------------------------------------------------------------- 프리셋
PRESETS = {
    "clean": "노이즈 없음 (원본)",
    "n1_tilt_light": "약한 기울기 + 완만한 조명 불균일 + 미세 그레인",
    "n2_shadow_persp": "그림자 + 원근 왜곡 + 배경 합성 + 색온도 편차",
    "n3_fold_crumple": "접힘 자국 2회 + 구김 + 기울기 + 배경 합성",
    "n4_lowres_blur": "저해상도 + 초점 흐림 + 강한 JPEG 압축",
    "n5_heavy_mixed": "원근 + 그림자 + 접힘 + 반사광 + 모션블러 + 저해상도 + 색편차 (복합)",
}


def augment(rgb, preset, seed, long_side=1500):
    """rgb(np.uint8) → 증강된 rgb(np.uint8)."""
    rnd = np.random.RandomState(seed)
    if preset == "clean":
        out = rgb
        return _resize_long(out, long_side)

    if preset == "n1_tilt_light":
        x = illumination(rgb, rnd, vig=0.16, grad=0.12)
        x = composite(geom(to_rgba(x), rnd, rot=1.8, persp=0.004, pad=0.04), rnd, use_bg=False)
        x = grain(x, rnd, 3.5)
        x = _resize_long(x, long_side)
        return jpeg(x, 88)

    if preset == "n2_shadow_persp":
        x = shadow(rgb, rnd, strength=rnd.uniform(0.28, 0.44))
        x = illumination(x, rnd, vig=0.24, grad=0.18)
        x = composite(geom(to_rgba(x), rnd, rot=3.5, persp=0.022, pad=0.10), rnd, use_bg=True)
        x = auto_exposure(x)
        x = color_cast(x, rnd, 0.09)
        x = grain(x, rnd, 5.0)
        x = _resize_long(x, int(long_side * 0.92))
        return jpeg(x, 78)

    if preset == "n3_fold_crumple":
        x = fold(rgb, rnd, n_lines=2, depth=rnd.uniform(0.16, 0.26))
        x = crumple(x, rnd, amp=0.13)
        x = illumination(x, rnd, vig=0.20, grad=0.15)
        x = composite(geom(to_rgba(x), rnd, rot=4.5, persp=0.012, pad=0.10), rnd, use_bg=True)
        x = auto_exposure(x)
        x = grain(x, rnd, 6.0)
        x = _resize_long(x, int(long_side * 0.90))
        return jpeg(x, 76)

    if preset == "n4_lowres_blur":
        x = illumination(rgb, rnd, vig=0.18, grad=0.13)
        x = composite(geom(to_rgba(x), rnd, rot=2.2, persp=0.008, pad=0.05), rnd, use_bg=False)
        x = auto_exposure(x)
        x = _resize_long(x, int(long_side * 0.80))
        x = defocus(x, rnd.uniform(0.5, 1.0))
        x = lowres(x, rnd.uniform(1.35, 1.95))
        x = grain(x, rnd, 5.5)
        return jpeg(x, int(rnd.randint(42, 60)))

    if preset == "n5_heavy_mixed":
        x = fold(rgb, rnd, n_lines=1, depth=rnd.uniform(0.18, 0.28))
        x = crumple(x, rnd, amp=0.15)
        x = shadow(x, rnd, strength=rnd.uniform(0.26, 0.40))
        x = glare(x, rnd, strength=rnd.uniform(0.22, 0.40))
        x = illumination(x, rnd, vig=0.24, grad=0.18)
        x = composite(geom(to_rgba(x), rnd, rot=7.0, persp=0.038, pad=0.13), rnd, use_bg=True)
        x = auto_exposure(x)
        x = color_cast(x, rnd, 0.12)
        x = motion_blur(x, rnd, k=int(rnd.randint(3, 7)))
        x = _resize_long(x, int(long_side * 0.74))
        x = lowres(x, rnd.uniform(1.25, 1.75))
        x = grain(x, rnd, 8.0)
        return jpeg(x, int(rnd.randint(36, 52)))

    raise ValueError(preset)


def _resize_long(rgb, long_side):
    h, w = rgb.shape[:2]
    s = long_side / max(h, w)
    if abs(s - 1.0) < 0.01:
        return rgb
    interp = cv2.INTER_AREA if s < 1 else cv2.INTER_CUBIC
    return cv2.resize(rgb, (int(round(w * s)), int(round(h * s))), interpolation=interp)
