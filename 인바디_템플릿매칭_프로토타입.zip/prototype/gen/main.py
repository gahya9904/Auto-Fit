# -*- coding: utf-8 -*-
"""합성 데이터셋 일괄 생성 — 이미지 + OCR 정답 라벨."""
import os
import sys
import json
import csv
import argparse
import numpy as np
from PIL import Image

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from person import build_cohort, BMI_CLASSES            # noqa: E402
from inbody_html import render_html as inbody_html      # noqa: E402
from rx_html import build_rx, render_html as rx_html    # noqa: E402
from checkup import Checkup                             # noqa: E402
from checkup_html import render_html as chk_html        # noqa: E402
from render import Renderer                             # noqa: E402
from noise import augment, PRESETS                      # noqa: E402

INBODY_W, INBODY_H = 840, 1208
RX_W, RX_H = 820, 1160
CHK_W, CHK_H = 820, 1160
DOC_SIZE = {"inbody": (INBODY_W, INBODY_H), "rx": (RX_W, RX_H), "checkup": (CHK_W, CHK_H)}


def inbody_fields(p):
    """결과지에 인쇄되는 값 = OCR 정답."""
    slm = round(p.tbw + p.protein + 0.15 * p.mineral, 1)
    seg = lambda d, n: {k: round(v, n) for k, v in d.items()}
    return {
        "회원번호": p.member_no,
        "신장_cm": p.height, "연령": p.age,
        "성별": "남성" if p.sex == "M" else "여성",
        "검사일시": p.test_dt.strftime("%Y.%m.%d. %H:%M"),
        "체수분_L": p.tbw, "단백질_kg": p.protein, "무기질_kg": p.mineral,
        "체지방_kg": p.bfm, "근육량_kg": slm, "제지방량_kg": p.ffm, "체중_kg": p.weight,
        "골격근량_kg": p.smm, "BMI": p.bmi, "체지방률_pct": p.pbf,
        "부위별근육_kg": seg(p.lean, 2), "부위별근육_pct": seg(p.lean_pct, 1),
        "부위별세포외수분비": seg(p.seg_ecwr, 3),
        "부위별체지방_kg": seg(p.fat, 1), "부위별체지방_pct": seg(p.fat_pct, 1),
        "세포외수분비": p.ecw_ratio, "인바디점수": p.score,
        "내장지방단면적_cm2": p.vfa, "적정체중_kg": p.ideal_weight,
        "체중조절_kg": p.w_ctrl, "지방조절_kg": p.f_ctrl, "근육조절_kg": p.m_ctrl,
        "신체균형평가": p.balance,
        "세포내수분_L": p.icw, "세포외수분_L": p.ecw,
        "기초대사량_kcal": p.bmr, "SMI_kg_m2": p.smi, "위상각_deg": p.phase_angle,
        "신체변화": [{"일시": r["date"].strftime("%y.%m.%d %H:%M"), "체중": r["weight"],
                   "골격근량": r["smm"], "체지방률": r["pbf"], "세포외수분비": r["ecwr"]}
                  for r in p.history],
    }


def rx_fields(f):
    g = dict(f)
    g["발급연월일"] = f["발급연월일"].isoformat()
    g["조제연월일"] = f["조제연월일"].isoformat()
    return g


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="dataset")
    ap.add_argument("--per-class", type=int, default=6)
    ap.add_argument("--long-side", type=int, default=1500)
    ap.add_argument("--scale", type=float, default=1.9)
    ap.add_argument("--quality", type=int, default=84)
    ap.add_argument("--docs", default="inbody,rx,checkup",
                    help="생성할 문서 종류 (쉼표 구분)")
    ap.add_argument("--merge", action="store_true",
                    help="기존 ground_truth.json에 이어붙인다")
    a = ap.parse_args()

    people = build_cohort(per_class=a.per_class)
    errs = [e for p in people for e in p.check()]
    if errs:
        print("물리 일관성 오류:", errs[:5])
        sys.exit(1)
    print(f"인물 {len(people)}명 · 물리 일관성 검증 통과")

    docs = [d.strip() for d in a.docs.split(",") if d.strip()]
    r = Renderer(scale=a.scale)
    records, idx = [], {k: 0 for k, *_ in BMI_CLASSES}

    for p in people:
        i = idx[p.cls_key]
        idx[p.cls_key] += 1
        pid = f"{p.cls_key}_{i:02d}"
        rxf = build_rx(p, p.seed + 7)

        chk = Checkup(p, rxf)
        cerr = chk.check()
        if cerr:
            print("검진 수식 오류:", cerr); sys.exit(1)

        base, tmps = {}, []
        html_of = {"inbody": lambda: inbody_html(p),
                   "rx": lambda: rx_html(rxf),
                   "checkup": lambda: chk_html(p, chk)}
        for doc in docs:
            t = f"/tmp/_{doc}_{pid}.png"
            w, h = DOC_SIZE[doc]
            r.shot(html_of[doc](), t, w, h)
            base[doc] = np.array(Image.open(t).convert("RGB"))
            tmps.append(t)

        for doc in docs:
            for pi, preset in enumerate(PRESETS):
                img = augment(base[doc], preset,
                              seed=p.seed * 31 + pi * 7 + {"inbody": 0, "rx": 3, "checkup": 6}[doc],
                              long_side=a.long_side)
                rel = f"images/{doc}/{p.cls_key}/{doc}_{pid}_{preset}.jpg"
                dst = os.path.join(a.out, rel)
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                Image.fromarray(img).save(dst, "JPEG", quality=a.quality, subsampling=1)
                records.append({
                    "image": rel, "doc_type": doc, "noise_preset": preset,
                    "noise_desc": PRESETS[preset],
                    "bmi_class": p.cls_key, "bmi_class_kr": p.cls_label,
                    "person_id": pid, "width": img.shape[1], "height": img.shape[0],
                    "subject": {"성별": "남성" if p.sex == "M" else "여성", "연령": p.age,
                                "신장_cm": p.height, "체중_kg": p.weight, "BMI": p.bmi},
                    "fields": {"inbody": lambda: inbody_fields(p),
                               "rx": lambda: rx_fields(rxf),
                               "checkup": lambda: chk.fields()}[doc](),
                })
        for t in tmps:
            os.remove(t)
        print(f"  [{p.cls_label:4s}] {pid} {('남' if p.sex=='M' else '여')} {p.age}세 "
              f"BMI {p.bmi} 검진:{chk.overall} → {len(PRESETS)*len(docs)}장")

    r.close()

    # ---- 라벨 저장
    lab = os.path.join(a.out, "labels")
    os.makedirs(lab, exist_ok=True)
    gt_path = os.path.join(lab, "ground_truth.json")
    if a.merge and os.path.exists(gt_path):
        old = json.load(open(gt_path, encoding="utf-8"))["records"]
        keep = [x for x in old if x["doc_type"] not in docs]
        records = keep + records
        records.sort(key=lambda x: (x["bmi_class"], x["person_id"], x["doc_type"],
                                    x["noise_preset"]))
        print(f"기존 {len(keep)}건 유지 + 신규 {len(records)-len(keep)}건")
    with open(gt_path, "w", encoding="utf-8") as fp:
        json.dump({"count": len(records), "presets": PRESETS,
                   "bmi_classes": [{"key": k, "label": l, "bmi_min": lo, "bmi_max": hi}
                                   for k, l, lo, hi in BMI_CLASSES],
                   "records": records}, fp, ensure_ascii=False, indent=1)

    with open(os.path.join(lab, "index.csv"), "w", encoding="utf-8-sig", newline="") as fp:
        w = csv.writer(fp)
        w.writerow(["image", "doc_type", "noise_preset", "bmi_class", "person_id",
                    "sex", "age", "height_cm", "weight_kg", "bmi", "width", "height"])
        for x in records:
            s = x["subject"]
            w.writerow([x["image"], x["doc_type"], x["noise_preset"], x["bmi_class_kr"],
                        x["person_id"], s["성별"], s["연령"], s["신장_cm"], s["체중_kg"],
                        s["BMI"], x["width"], x["height"]])

    with open(os.path.join(lab, "rx_drugs.csv"), "w", encoding="utf-8-sig", newline="") as fp:
        w = csv.writer(fp)
        w.writerow(["image", "row", "의약품명", "1회투약량", "1일투여횟수", "총투약일수", "용법"])
        for x in records:
            if x["doc_type"] != "rx":
                continue
            for i, d in enumerate(x["fields"]["의약품"]):
                w.writerow([x["image"], i + 1, d["name"], d["dose"], d["freq"],
                            d["days"], d["usage"]])

    with open(os.path.join(lab, "inbody_fields.csv"), "w", encoding="utf-8-sig", newline="") as fp:
        keys = ["체중_kg", "골격근량_kg", "체지방_kg", "BMI", "체지방률_pct", "제지방량_kg",
                "체수분_L", "단백질_kg", "무기질_kg", "세포외수분비", "인바디점수",
                "내장지방단면적_cm2", "기초대사량_kcal", "SMI_kg_m2", "위상각_deg"]
        w = csv.writer(fp)
        w.writerow(["image"] + keys)
        for x in records:
            if x["doc_type"] != "inbody":
                continue
            w.writerow([x["image"]] + [x["fields"][k] for k in keys])

    with open(os.path.join(lab, "checkup_fields.csv"), "w", encoding="utf-8-sig",
              newline="") as fp:
        keys = ["수축기혈압", "이완기혈압", "공복혈당_mg_dL", "총콜레스테롤_mg_dL",
                "HDL콜레스테롤_mg_dL", "중성지방_mg_dL", "LDL콜레스테롤_mg_dL",
                "혈색소_g_dL", "혈청크레아티닌_mg_dL", "eGFR", "AST_IU_L", "ALT_IU_L",
                "감마지티피_IU_L", "체질량지수", "허리둘레_cm", "요단백", "종합판정"]
        w = csv.writer(fp)
        w.writerow(["image"] + keys)
        for x in records:
            if x["doc_type"] != "checkup":
                continue
            w.writerow([x["image"]] + [x["fields"][k] for k in keys])

    total = sum(os.path.getsize(os.path.join(dp, f))
                for dp, _, fs in os.walk(a.out) for f in fs)
    print(f"\n총 {len(records)}장 · {total/1e6:.1f} MB → {a.out}/")


if __name__ == "__main__":
    main()
