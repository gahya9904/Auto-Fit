# -*- coding: utf-8 -*-
"""
합성 인물 생성기 — 체성분 값이 물리적으로 일관되도록 계산한다.

계수는 업로드된 실제 InBody 770S 결과지(156.8cm / 59.1kg / 51세 여성)를
역산해 보정했다. 검증 근거:
    FFM  = TBW + Protein + Minerals   27.8 + 7.3 + 2.65 = 37.75 ≈ 37.7
    체중 = FFM + BFM                  37.7 + 21.4       = 59.1
    BMR  = 21.6 * FFM + 370           21.6*37.7+370     = 1185
    ECW비 = ECW / TBW                 11.0 / 27.8       = 0.396
    SMI  = ASM / H^2                  14.26 / 1.568^2   = 5.8
    적정체중 = H^2 * 21.0 (여) = 51.6 → 체중조절 -7.5 = 지방조절 -9.5 + 근육조절 +2.0
"""
import random
import datetime as dt

# ---------------------------------------------------------------- 체형 구간
# 대한비만학회(KSSO) 한국인 기준
BMI_CLASSES = [
    ("underweight", "저체중",   16.0, 18.4),
    ("normal",      "정상",     18.6, 22.9),
    ("overweight",  "과체중",   23.1, 24.9),
    ("obese1",      "비만",     25.1, 29.9),
    ("obese2",      "고도비만", 30.1, 39.0),
]

SURNAMES = list("김이박최정강조윤장임한오서신권황안송류전홍고문양손배백허유남심노하곽성차주우구")
GIVEN_M = ["민준","서준","도윤","예준","시우","하준","지호","준서","건우","현우","우진","선우",
           "영수","정호","성민","태현","동현","재현","기훈","пован","상우","진우","경호","병철",
           "종석","حسن","승현","윤호","대성","광수","호진","석진","용준","정훈","재민","수호"]
GIVEN_F = ["서연","서윤","지우","하윤","하은","민서","지유","윤서","채원","수아","지아","다은",
           "은지","미영","정숙","영희","현주","소연","혜진","은영","지연","수빈","가은","예린",
           "보람","다인","윤아","세영","나연","주희","영란","경자","순옥","말순","정미","유진"]
# 조합 오류 방지: 비한글 항목 제거
GIVEN_M = [n for n in GIVEN_M if all("가" <= ch <= "힣" for ch in n)]
GIVEN_F = [n for n in GIVEN_F if all("가" <= ch <= "힣" for ch in n)]


def _rrn(birth: dt.date, sex: str) -> str:
    """
    구조는 실제 주민등록번호와 동일하되 **검증코드를 의도적으로 틀리게** 만든다.
    → 어떤 실존 인물의 번호와도 일치할 수 없다. OCR 입장에서는 형식이 같아 무해하다.
    """
    front = birth.strftime("%y%m%d")
    if birth.year < 2000:
        g = "1" if sex == "M" else "2"
    else:
        g = "3" if sex == "M" else "4"
    mid = "".join(random.choice("0123456789") for _ in range(6))
    digits = [int(c) for c in front + g + mid[:5]]
    w = [2, 3, 4, 5, 6, 7, 8, 9, 2, 3, 4, 5]
    valid = (11 - sum(d * x for d, x in zip(digits, w)) % 11) % 10
    bad = (valid + random.randint(1, 9)) % 10          # 일부러 불일치
    return f"{front}-{g}{mid[:5]}{bad}"


class Person:
    def __init__(self, cls_key: str, seed: int):
        rnd = random.Random(seed)
        self.seed = seed
        key, label, lo, hi = next(c for c in BMI_CLASSES if c[0] == cls_key)
        self.cls_key, self.cls_label = key, label

        self.sex = rnd.choice(["M", "F"])
        self.age = rnd.choice(
            [rnd.randint(16, 24), rnd.randint(25, 39), rnd.randint(40, 54),
             rnd.randint(55, 69), rnd.randint(70, 84)]
        )
        base_h = 173.0 if self.sex == "M" else 160.0
        if self.age >= 70:
            base_h -= 5.0
        elif self.age >= 55:
            base_h -= 2.5
        self.height = round(rnd.gauss(base_h, 6.0), 1)
        self.height = min(max(self.height, 145.0), 192.0)

        self.bmi = round(rnd.uniform(lo, hi), 1)
        hm = self.height / 100.0
        self.weight = round(self.bmi * hm * hm, 1)

        # ---- 체지방률: Deurenberg 식 + 개인차
        male = 1 if self.sex == "M" else 0
        pbf = 1.20 * self.bmi + 0.23 * self.age - 10.8 * male - 5.4
        pbf += rnd.gauss(0, 1.8)
        self.pbf = round(min(max(pbf, 4.0), 58.0), 1)

        # ---- 1차 분해
        self.bfm = round(self.weight * self.pbf / 100.0, 1)
        self.ffm = round(self.weight - self.bfm, 1)
        f = self.ffm
        self.tbw = round(f * rnd.uniform(0.734, 0.741), 1)
        self.protein = round(f * rnd.uniform(0.191, 0.196), 1)
        self.mineral = round(f - self.tbw - self.protein, 2)   # 합이 정확히 FFM

        # ---- 세포내외 수분
        ecwr = 0.3715 + (self.age - 30) * 0.00042 + (self.pbf - 25) * 0.00075
        ecwr += rnd.gauss(0, 0.003)
        self.ecw_ratio = round(min(max(ecwr, 0.355), 0.438), 3)
        self.ecw = round(self.tbw * self.ecw_ratio, 1)
        self.icw = round(self.tbw - self.ecw, 1)

        # ---- 근육
        smm_r = 0.528 - (0.02 if self.age >= 65 else 0.0) + rnd.gauss(0, 0.008)
        self.smm = round(f * smm_r, 1)
        asm_r = 0.378 - (0.015 if self.age >= 65 else 0.0) + rnd.gauss(0, 0.006)
        self.asm = f * asm_r
        self.smi = round(self.asm / (hm * hm), 1)

        # ---- 표준값 (막대그래프 기준선)
        self.w_std = (22.0 if self.sex == "M" else 21.0) * hm * hm
        self.pbf_target = 15.0 if self.sex == "M" else 23.0
        self.ffm_std = self.w_std * (1 - self.pbf_target / 100.0)
        self.smm_std = 0.528 * self.ffm_std
        self.bfm_std = self.w_std * self.pbf_target / 100.0

        # ---- 부위별 근육 (좌우 비대칭 포함)
        d = lambda: rnd.uniform(-0.045, 0.045)
        ra = f * 0.0497 * (1 + d()); la = f * 0.0497 * (1 + d())
        rl = f * 0.1564 * (1 + d()); ll = f * 0.1564 * (1 + d())
        tr = f * 0.849 - (ra + la + rl + ll)
        self.lean = {"RA": round(ra, 2), "LA": round(la, 2), "TR": round(tr, 1),
                     "RL": round(rl, 2), "LL": round(ll, 2)}
        std_l = {"RA": 0.0497, "LA": 0.0497, "TR": 0.4483, "RL": 0.1564, "LL": 0.1564}
        self.lean_pct = {k: round(self.lean[k] / (std_l[k] * self.ffm_std) * 100, 1)
                         for k in self.lean}
        self.seg_ecwr = {k: round(self.ecw_ratio + rnd.uniform(-0.017, 0.006), 3)
                         for k in self.lean}

        # ---- 부위별 체지방
        b = self.bfm
        fra = b * 0.0726 * (1 + d()); fla = b * 0.0726 * (1 + d())
        frl = b * 0.1868 * (1 + d()); fll = b * 0.1868 * (1 + d())
        ftr = b * 0.9278 - (fra + fla + frl + fll)
        self.fat = {"RA": round(fra, 1), "LA": round(fla, 1), "TR": round(ftr, 1),
                    "RL": round(frl, 1), "LL": round(fll, 1)}
        std_f = {"RA": 0.0726, "LA": 0.0726, "TR": 0.409, "RL": 0.1868, "LL": 0.1868}
        self.fat_pct = {k: round(self.fat[k] / (std_f[k] * self.bfm_std) * 100, 1)
                        for k in self.fat}

        # ---- 파생 지표
        self.bmr = int(round(21.6 * f + 370))
        self.bmr_lo, self.bmr_hi = int(self.bmr * 0.94), int(self.bmr * 1.06)
        vfa = 3.0 * self.bfm + 1.0 * self.age - 5 + (14 if male else 0) + rnd.gauss(0, 8)
        self.vfa = round(min(max(vfa, 8.0), 260.0), 1)

        pha = 6.55 - 0.022 * self.age - 0.05 * max(0, self.pbf - self.pbf_target) \
              + (0.45 if male else 0) + rnd.gauss(0, 0.25)
        self.phase_angle = round(min(max(pha, 2.8), 8.6), 1)

        excess = max(0.0, self.pbf - self.pbf_target)
        deficit = max(0.0, 100 - self.smm / self.smm_std * 100)
        sc = 82 - 0.78 * excess - 0.55 * deficit + rnd.gauss(0, 2)
        self.score = int(min(max(sc, 32), 96))

        # ---- 체중/지방/근육 조절
        self.ideal_weight = round(self.w_std, 1)
        self.w_ctrl = round(self.ideal_weight - self.weight, 1)
        self.f_ctrl = round(self.w_std * self.pbf_target / 100.0 - self.bfm, 1)
        self.m_ctrl = round(self.w_ctrl - self.f_ctrl, 1)

        # ---- 신체균형 평가
        def bal(a, b_):
            r = abs(a - b_) / max(a, b_)
            return "균형" if r < 0.05 else ("약한불균형" if r < 0.11 else "심한불균형")
        self.balance = {
            "상체좌우": bal(self.lean["RA"], self.lean["LA"]),
            "하체좌우": bal(self.lean["RL"], self.lean["LL"]),
            "상체하체": "균형" if 0.9 <= (self.lean_pct["RA"] + self.lean_pct["LA"]) /
                       max(1e-6, self.lean_pct["RL"] + self.lean_pct["LL"]) <= 1.1
                       else "약한불균형",
        }

        # ---- 신원
        self.name = (rnd.choice(SURNAMES) +
                     rnd.choice(GIVEN_M if self.sex == "M" else GIVEN_F))
        self.member_no = f"{rnd.randint(10000, 99999)}"
        today = dt.date(2026, 8, 12)
        self.birth = dt.date(today.year - self.age, rnd.randint(1, 12), rnd.randint(1, 28))
        self.rrn = _rrn(self.birth, self.sex)
        self.test_dt = dt.datetime(2026, rnd.randint(1, 8), rnd.randint(1, 28),
                                   rnd.randint(8, 20), rnd.randint(0, 59))

        # ---- 과거 8회 측정 이력
        self.history = self._history(rnd)

        # ---- 임피던스 (근육량 낮을수록 Z 상승)
        base_z = {"RA": 300, "LA": 305, "TR": 24, "RL": 250, "LL": 252}
        k = 40.0 / max(12.0, self.smm)
        self.impedance = {}
        for seg, z0 in base_z.items():
            self.impedance[seg] = [round(z0 * k * m * rnd.uniform(0.97, 1.03), 1)
                                   for m in (1.06, 1.0, 0.93, 0.88, 0.85)]

    def _history(self, rnd):
        n = 8
        rows, d = [], self.test_dt
        w, smm, pbf, ecr = self.weight, self.smm, self.pbf, self.ecw_ratio
        drift = rnd.choice([-1, 1]) * rnd.uniform(0.3, 1.3)
        for i in range(n):
            rows.append({
                "date": d,
                "weight": round(w, 1),
                "smm": round(smm, 1),
                "pbf": round(pbf, 1),
                "ecwr": round(ecr, 3),
            })
            d = d - dt.timedelta(days=rnd.randint(28, 62),
                                 hours=rnd.randint(-5, 5), minutes=rnd.randint(-45, 45))
            w += drift + rnd.gauss(0, 0.4)
            smm += rnd.gauss(0, 0.25)
            pbf += drift * 0.55 + rnd.gauss(0, 0.35)
            ecr += rnd.gauss(0, 0.0018)
        return list(reversed(rows))

    # ---- 물리 일관성 자체 검증
    def check(self):
        errs = []
        if abs((self.tbw + self.protein + self.mineral) - self.ffm) > 0.15:
            errs.append(f"FFM 합 불일치 {self.seed}")
        if abs((self.ffm + self.bfm) - self.weight) > 0.15:
            errs.append(f"체중 합 불일치 {self.seed}")
        if abs((self.icw + self.ecw) - self.tbw) > 0.15:
            errs.append(f"체수분 합 불일치 {self.seed}")
        if abs(self.bmr - (21.6 * self.ffm + 370)) > 1.5:
            errs.append(f"BMR 불일치 {self.seed}")
        if abs((self.f_ctrl + self.m_ctrl) - self.w_ctrl) > 0.15:
            errs.append(f"체중조절 합 불일치 {self.seed}")
        if abs(self.bmi - self.weight / (self.height / 100) ** 2) > 0.15:
            errs.append(f"BMI 불일치 {self.seed}")
        return errs


def build_cohort(per_class: int = 6, seed0: int = 20260812):
    people = []
    for ci, (key, _, _, _) in enumerate(BMI_CLASSES):
        for i in range(per_class):
            people.append(Person(key, seed0 + ci * 1000 + i))
    return people


if __name__ == "__main__":
    ppl = build_cohort()
    bad = [e for p in ppl for e in p.check()]
    print(f"인원 {len(ppl)}명 / 물리 일관성 오류 {len(bad)}건")
    for e in bad[:10]:
        print("  ", e)
    for p in ppl[::6]:
        print(f"{p.cls_label:5s} {p.sex} {p.age:3d}세 {p.height:5.1f}cm {p.weight:5.1f}kg "
              f"BMI {p.bmi:4.1f} PBF {p.pbf:4.1f}% SMM {p.smm:4.1f} VFA {p.vfa:5.1f} "
              f"점수 {p.score} 위상각 {p.phase_angle}")
