# -*- coding: utf-8 -*-
"""
일반건강검진 결과통보서 — 검사 수치 모델 + 법정 판정 로직.

핵심 설계: 수치를 난수로 흩뿌리지 않고
  ① BMI·연령·성별에서 임상적으로 타당하게 생성하고
  ② LDL은 Friedewald 공식, eGFR은 MDRD 공식으로 '계산'하며
  ③ 판정(정상A/정상B/질환의심/유질환자)은 국가검진 기준을 값에 적용해 도출한다.
→ OCR 결과의 교차검증 규칙을 이 데이터로 그대로 만들 수 있다.
   (예: 인식된 TC-HDL-TG/5 가 LDL과 안 맞으면 오인식 확정)
"""
import random

# ─────────────────────────────── 판정 기준 (국가건강검진)
# (항목, 정상 상한, 경계 상한) — 초과 시 질환의심
CUT = {
    "sbp":  (119, 139), "dbp": (79, 89),
    "fbs":  (99, 125),
    "tc":   (199, 239),
    "tg":   (149, 199),
    "ldl":  (129, 159),
    "ast":  (40, 50), "alt": (35, 45),
}
GGT = {"M": (63, 77), "F": (35, 45)}
HB_LO = {"M": 13.0, "F": 12.0}
HB_HI = {"M": 16.5, "F": 15.5}
WC_CUT = {"M": 90, "F": 85}


def _ln(rnd, mu, sigma, lo, hi):
    """오른쪽으로 꼬리가 긴 검사치(TG, 간수치 등)용."""
    v = mu * (2.718281828 ** rnd.gauss(0, sigma))
    return min(max(v, lo), hi)


class Checkup:
    def __init__(self, p, rx=None, seed=None):
        rnd = random.Random(seed if seed is not None else p.seed + 991)
        self.p = p
        male = p.sex == "M"
        b = p.bmi - 22.0          # 기준 BMI로부터의 편차
        a = p.age

        # ── 계측검사
        self.height = p.height
        self.weight = p.weight
        self.bmi = p.bmi
        self.waist = round(3.1 * p.bmi + 0.12 * a + (5 if male else 1) + rnd.gauss(0, 3.0), 1)
        self.vision = (round(min(1.5, max(0.1, rnd.gauss(1.2 - a * 0.008, 0.28))), 1),
                       round(min(1.5, max(0.1, rnd.gauss(1.2 - a * 0.008, 0.28))), 1))
        self.hearing = ("정상" if rnd.random() > (0.04 + max(0, a - 55) * 0.006) else "비정상",
                        "정상" if rnd.random() > (0.04 + max(0, a - 55) * 0.006) else "비정상")
        self.sbp = int(round(102 + 0.85 * b + 0.38 * a + rnd.gauss(0, 7)))
        self.dbp = int(round(64 + 0.55 * b + 0.18 * a + rnd.gauss(0, 5.5)))
        self.sbp = min(max(self.sbp, 90), 200)
        self.dbp = min(max(self.dbp, 50), 125)

        # ── 요검사
        r = rnd.random()
        risk = 0.015 + max(0, b) * 0.004 + max(0, a - 55) * 0.0015
        self.urine = "음성" if r > risk * 2 else ("약양성" if r > risk else "양성")

        # ── 혈액검사
        self.hb = round((15.4 if male else 13.6) - 0.010 * a + rnd.gauss(0, 0.75), 1)
        self.fbs = int(round(_ln(rnd, 84 + 1.0 * b + 0.25 * a, 0.11, 65, 320)))
        self.tc = int(round(165 + 1.5 * b + 0.45 * a + rnd.gauss(0, 22)))
        self.tg = int(round(_ln(rnd, 70 + 5.0 * max(b, -3) + 0.6 * a, 0.32, 30, 600)))
        self.hdl = int(round(62 - 0.8 * b - (10 if male else 0) + rnd.gauss(0, 9)))
        self.hdl = min(max(self.hdl, 20), 110)
        # LDL은 Friedewald 공식으로 '계산' (TG<400에서 유효)
        self.ldl = int(round(self.tc - self.hdl - self.tg / 5)) if self.tg < 400 else None
        if self.ldl is not None:
            self.ldl = max(self.ldl, 25)

        self.cr = round((0.95 if male else 0.74) + 0.002 * a + rnd.gauss(0, 0.11), 2)
        self.cr = min(max(self.cr, 0.40), 3.20)
        # eGFR은 MDRD 공식으로 '계산'
        egfr = 175 * (self.cr ** -1.154) * (a ** -0.203) * (1 if male else 0.742)
        self.egfr = int(round(min(egfr, 160)))

        self.ast = int(round(_ln(rnd, 19 + 0.6 * max(b, 0), 0.26, 8, 300)))
        self.alt = int(round(_ln(rnd, 18 + 1.0 * max(b, 0), 0.32, 5, 300)))
        self.ggt = int(round(_ln(rnd, (26 if male else 16) + 1.4 * max(b, 0), 0.38, 6, 400)))

        # ── 영상검사
        self.xray = "정상" if rnd.random() > 0.06 else rnd.choice(
            ["비활동성 폐결핵", "폐 결절 의심", "심비대 의심", "진구성 병변"])

        # ── 유질환 여부 (처방전과 연동)
        codes = set(rx["질병분류기호"]) if rx else set()
        self.tx_htn = "I10" in codes
        self.tx_dm = "E11" in codes
        self.tx_lipid = "E78" in codes

        # ── 항목별 판정
        self.j = self._judge(male)
        self.overall, self.overall_detail = self._overall()
        self.opinion = self._opinion()

        # ── 검진기관·의사
        self.org, self.org_code = rnd.choice([
            ("한국건강관리협회 서울강남지부", "36110001"),
            ("서울시티건강검진센터", "36230014"),
            ("미래로종합검진센터", "31450027"),
            ("건강한내일의원 검진센터", "31770052"),
            ("대한종합건진센터", "36880009"),
        ])
        self.doctor = rnd.choice(["김도현", "이수정", "박준영", "최민아", "정재우", "한소희"])
        self.lic = f"{rnd.randint(20000, 129999)}"
        self.exam_date = p.test_dt.date()
        self.judge_date = p.test_dt.date()

        # ── 생활습관
        self.smoke = rnd.choices(["비흡연", "과거흡연", "현재흡연"],
                                 weights=[58 if not male else 34, 20, 22 if not male else 46])[0]
        self.drink = rnd.choices(["안 마심", "주 1회 이하", "주 2~3회", "주 4회 이상"],
                                 weights=[26, 38, 26, 10])[0]
        self.exercise = rnd.choices(["주 5회 이상", "주 3~4회", "주 1~2회", "거의 안 함"],
                                    weights=[12, 22, 34, 32])[0]

    # ────────────────────────── 항목별 판정
    def _judge(self, male):
        def lvl(v, key):
            n, w = CUT[key]
            return "정상" if v <= n else ("경계" if v <= w else "질환의심")

        g = GGT["M" if male else "F"]
        sx = "M" if male else "F"
        j = {}
        bp = max(["정상", "경계", "질환의심"].index(lvl(self.sbp, "sbp")),
                 ["정상", "경계", "질환의심"].index(lvl(self.dbp, "dbp")))
        j["고혈압"] = ["정상", "경계", "질환의심"][bp]
        j["당뇨병"] = lvl(self.fbs, "fbs")
        lipid = max(["정상", "경계", "질환의심"].index(lvl(self.tc, "tc")),
                    ["정상", "경계", "질환의심"].index(lvl(self.tg, "tg")),
                    ["정상", "경계", "질환의심"].index(lvl(self.ldl, "ldl")) if self.ldl else 0,
                    # 이상지질혈증 진단기준상 '낮은 HDL'은 40 미만. 40~59는 정상으로 본다.
                    2 if self.hdl < 40 else 0)
        j["이상지질혈증"] = ["정상", "경계", "질환의심"][lipid]
        j["신장질환"] = "질환의심" if (self.cr > 1.5 or self.egfr < 60) else "정상"
        liver = max(["정상", "경계", "질환의심"].index(lvl(self.ast, "ast")),
                    ["정상", "경계", "질환의심"].index(lvl(self.alt, "alt")),
                    0 if self.ggt <= g[0] else (1 if self.ggt <= g[1] else 2))
        j["간장질환"] = ["정상", "경계", "질환의심"][liver]
        j["빈혈"] = "질환의심" if self.hb < HB_LO[sx] else "정상"
        j["요단백"] = {"음성": "정상", "약양성": "경계", "양성": "질환의심"}[self.urine]
        j["비만"] = ("저체중" if self.bmi < 18.5 else "정상" if self.bmi < 23
                   else "비만전단계" if self.bmi < 25 else "비만")
        j["복부비만"] = "해당" if self.waist >= WC_CUT[sx] else "정상"
        return j

    # ────────────────────────── 종합판정
    def _overall(self):
        if self.tx_htn or self.tx_dm:
            d = [n for n, t in (("고혈압", self.tx_htn), ("당뇨병", self.tx_dm)) if t]
            return "유질환자", " · ".join(d)
        crit = [k for k in ("고혈압", "당뇨병") if self.j[k] == "질환의심"]
        if crit:
            return "질환의심", " · ".join(crit)
        other = [k for k, v in self.j.items()
                 if v == "질환의심" and k in ("이상지질혈증", "신장질환", "간장질환", "빈혈", "요단백")]
        if other:
            return "일반질환의심", " · ".join(other)
        if self.j["비만"] == "비만":
            other.append("비만")
        bd = [k for k, v in self.j.items() if v == "경계"]
        if bd or self.j["비만"] in ("비만", "저체중"):
            return "정상B", " · ".join(bd + ([self.j["비만"]] if self.j["비만"] != "정상" else []))
        return "정상A", "이상 소견 없음"

    # ────────────────────────── 종합소견 문장
    def _opinion(self):
        s = []
        if self.overall == "유질환자":
            s.append(f"{self.overall_detail}(으)로 치료 중이십니다. 현재 치료를 유지하시고 "
                     f"정기적으로 담당 의사와 상담하시기 바랍니다.")
        if self.j["고혈압"] == "질환의심":
            s.append(f"혈압이 {self.sbp}/{self.dbp}mmHg로 높습니다. 2차 검진 또는 "
                     f"의료기관 진료를 받으시기 바랍니다.")
        elif self.j["고혈압"] == "경계":
            s.append("혈압이 경계 범위입니다. 저염식과 규칙적인 유산소 운동을 권합니다.")
        if self.j["당뇨병"] == "질환의심":
            s.append(f"공복혈당이 {self.fbs}mg/dL로 당뇨병이 의심됩니다. 확진 검사가 필요합니다.")
        elif self.j["당뇨병"] == "경계":
            s.append("공복혈당이 당뇨 전단계입니다. 단순당 섭취를 줄이고 체중을 관리하십시오.")
        if self.j["이상지질혈증"] in ("경계", "질환의심"):
            s.append(f"총콜레스테롤 {self.tc}, 중성지방 {self.tg}, HDL {self.hdl}mg/dL로 "
                     f"지질 수치 관리가 필요합니다.")
        if self.j["간장질환"] in ("경계", "질환의심"):
            s.append(f"간수치(AST {self.ast} / ALT {self.alt} / γ-GTP {self.ggt})가 높습니다. "
                     f"금주와 체중 감량을 권합니다.")
        if self.j["신장질환"] == "질환의심":
            s.append(f"신장기능(크레아티닌 {self.cr}, e-GFR {self.egfr})의 추가 평가가 필요합니다.")
        if self.j["빈혈"] == "질환의심":
            s.append(f"혈색소가 {self.hb}g/dL로 빈혈이 의심됩니다.")
        if self.j["비만"] == "비만":
            s.append(f"체질량지수 {self.bmi}kg/m²로 비만에 해당합니다. "
                     f"식사 조절과 주 150분 이상의 중강도 운동을 권합니다.")
        elif self.j["비만"] == "저체중":
            s.append(f"체질량지수 {self.bmi}kg/m²로 저체중입니다. 균형 잡힌 영양 섭취가 필요합니다.")
        if self.xray != "정상":
            s.append(f"흉부방사선검사에서 {self.xray} 소견이 있어 추가 검사가 필요합니다.")
        if not s:
            s.append("검사 결과 특이 소견이 없습니다. 현재의 건강한 생활습관을 유지하시기 바랍니다.")
        return " ".join(s)

    # ────────────────────────── 물리·수식 일관성 검증
    def check(self):
        e = []
        if self.tg < 400 and self.ldl is not None:
            if abs(self.ldl - (self.tc - self.hdl - self.tg / 5)) > 1.0:
                e.append(f"LDL Friedewald 불일치 seed={self.p.seed}")
        a, male = self.p.age, self.p.sex == "M"
        exp = 175 * (self.cr ** -1.154) * (a ** -0.203) * (1 if male else 0.742)
        if abs(self.egfr - min(exp, 160)) > 1.0:
            e.append(f"eGFR MDRD 불일치 seed={self.p.seed}")
        if abs(self.bmi - self.weight / (self.height / 100) ** 2) > 0.15:
            e.append(f"BMI 불일치 seed={self.p.seed}")
        return e

    # ────────────────────────── 정답 라벨
    def fields(self):
        return {
            "검진기관": self.org, "검진기관기호": self.org_code,
            "검진일": self.exam_date.isoformat(), "판정일": self.judge_date.isoformat(),
            "판정의사": self.doctor, "면허번호": self.lic,
            "신장_cm": self.height, "체중_kg": self.weight, "체질량지수": self.bmi,
            "허리둘레_cm": self.waist,
            "시력_좌": self.vision[0], "시력_우": self.vision[1],
            "청력_좌": self.hearing[0], "청력_우": self.hearing[1],
            "수축기혈압": self.sbp, "이완기혈압": self.dbp,
            "요단백": self.urine,
            "혈색소_g_dL": self.hb, "공복혈당_mg_dL": self.fbs,
            "총콜레스테롤_mg_dL": self.tc, "HDL콜레스테롤_mg_dL": self.hdl,
            "중성지방_mg_dL": self.tg, "LDL콜레스테롤_mg_dL": self.ldl,
            "혈청크레아티닌_mg_dL": self.cr, "eGFR": self.egfr,
            "AST_IU_L": self.ast, "ALT_IU_L": self.alt, "감마지티피_IU_L": self.ggt,
            "흉부방사선검사": self.xray,
            "항목별판정": self.j,
            "종합판정": self.overall, "종합판정상세": self.overall_detail,
            "종합소견": self.opinion,
            "흡연": self.smoke, "음주": self.drink, "신체활동": self.exercise,
        }


if __name__ == "__main__":
    import sys, os
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from person import build_cohort
    from rx_html import build_rx
    from collections import Counter

    ppl = build_cohort()
    cs = [Checkup(p, build_rx(p, p.seed + 7)) for p in ppl]
    errs = [e for c in cs for e in c.check()]
    print(f"{len(cs)}명 / 수식 일관성 오류 {len(errs)}건")
    print("종합판정 분포:", Counter(c.overall for c in cs))
    for c in cs[::5]:
        p = c.p
        print(f"{p.cls_label:5s} {p.sex} {p.age:3d}세 BMI {p.bmi:4.1f} | "
              f"BP {c.sbp}/{c.dbp} FBS {c.fbs:3d} TC {c.tc:3d} TG {c.tg:3d} "
              f"HDL {c.hdl:3d} LDL {str(c.ldl):>3s} AST {c.ast:3d} ALT {c.alt:3d} "
              f"→ {c.overall}({c.overall_detail})")
