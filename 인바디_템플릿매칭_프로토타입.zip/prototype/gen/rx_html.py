# -*- coding: utf-8 -*-
"""처방전(의료법 시행규칙 별지 제9호서식) HTML 재현 — 빈 서식 + 값 주입."""
import random
import datetime as dt

FONT = "'Noto Sans CJK KR','Noto Sans KR',sans-serif"

# 상병 → (KCD코드, 상병명, 후보 의약품)
# 의약품: (명칭, 1회 투약량, 1일 투여횟수, 총 투약일수 후보, 용법)
CONDITIONS = {
    "고혈압": ("I10", "본태성(원발성) 고혈압", [
        ("아모디핀정5mg", "1.0", "1", [28, 30, 60, 90], "1일 1회 아침 식후 30분"),
        ("노바스크정5mg", "1.0", "1", [28, 30, 90], "1일 1회 아침 식후 30분"),
        ("올메텍정20mg", "1.0", "1", [30, 60, 90], "1일 1회 아침 식후 30분"),
        ("트윈스타정40/5mg", "1.0", "1", [30, 90], "1일 1회 아침 식후 30분"),
        ("딜라트렌정12.5mg", "1.0", "2", [28, 30], "1일 2회 아침·저녁 식후 30분"),
    ]),
    "당뇨": ("E11", "2형 당뇨병", [
        ("다이아벡스정500mg", "1.0", "2", [28, 30, 90], "1일 2회 아침·저녁 식후 즉시"),
        ("자누비아정100mg", "1.0", "1", [30, 90], "1일 1회 아침 식후 30분"),
        ("아마릴정2mg", "1.0", "1", [28, 30], "1일 1회 아침 식전 30분"),
        ("포시가정10mg", "1.0", "1", [30, 90], "1일 1회 아침 식후 30분"),
        ("트라젠타정5mg", "1.0", "1", [30, 90], "1일 1회 아침 식후 30분"),
    ]),
    "이상지질혈증": ("E78", "지질단백대사장애 및 기타 지질증", [
        ("리피토정20mg", "1.0", "1", [30, 60, 90], "1일 1회 저녁 식후 30분"),
        ("크레스토정10mg", "1.0", "1", [30, 90], "1일 1회 저녁 식후 30분"),
        ("리바로정2mg", "1.0", "1", [28, 30, 90], "1일 1회 저녁 식후 30분"),
    ]),
    "위식도역류": ("K21", "위-식도역류병", [
        ("넥시움정40mg", "1.0", "1", [14, 28, 30], "1일 1회 아침 식전 30분"),
        ("란스톤LFDT정15mg", "1.0", "1", [14, 28], "1일 1회 아침 식전 30분"),
        ("가스모틴정5mg", "1.0", "3", [7, 14, 28], "1일 3회 매 식전 30분"),
    ]),
    "위염": ("K29", "위염 및 십이지장염", [
        ("스티렌투엑스정", "1.0", "2", [14, 28], "1일 2회 아침·저녁 식후 30분"),
        ("알마겔에프현탁액", "1.0", "3", [5, 7, 14], "1일 3회 매 식후 30분"),
        ("애엽95%에탄올연조엑스정", "1.0", "3", [7, 14], "1일 3회 매 식후 30분"),
    ]),
    "무릎관절증": ("M17", "무릎관절증", [
        ("쎄레브렉스캡슐200mg", "1.0", "2", [7, 14, 28], "1일 2회 아침·저녁 식후 30분"),
        ("아세클로페낙정100mg", "1.0", "2", [5, 7, 14], "1일 2회 아침·저녁 식후 30분"),
        ("조인스정200mg", "1.0", "3", [14, 28], "1일 3회 매 식후 30분"),
    ]),
    "등통증": ("M54", "등통증", [
        ("낙센에프정500mg", "1.0", "2", [3, 5, 7], "1일 2회 아침·저녁 식후 30분"),
        ("에페리손염산염정50mg", "1.0", "3", [5, 7, 14], "1일 3회 매 식후 30분"),
        ("타이레놀8시간이알서방정650mg", "1.0", "3", [3, 5, 7], "1일 3회 매 식후 30분"),
    ]),
    "갑상선기능저하": ("E03", "기타 갑상선기능저하증", [
        ("씬지로이드정0.1mg", "1.0", "1", [30, 60, 90], "1일 1회 아침 공복 복용"),
    ]),
    "통풍": ("M10", "통풍", [
        ("페브릭정40mg", "1.0", "1", [30, 90], "1일 1회 아침 식후 30분"),
        ("자이로릭정100mg", "1.0", "2", [28, 30], "1일 2회 아침·저녁 식후 30분"),
    ]),
    "감기": ("J00", "급성 비인두염[감기]", [
        ("코푸시럽에스", "10.0", "3", [3, 5], "1일 3회 매 식후 30분"),
        ("지르텍정10mg", "1.0", "1", [3, 5, 7], "1일 1회 취침 전"),
        ("타이레놀정500mg", "1.0", "3", [3, 5], "1일 3회 매 식후 30분"),
    ]),
    "기관지염": ("J20", "급성 기관지염", [
        ("뮤코펙트정30mg", "1.0", "3", [5, 7], "1일 3회 매 식후 30분"),
        ("씨투스정10mg", "1.0", "1", [7, 14], "1일 1회 취침 전"),
        ("오구멘틴정625mg", "1.0", "3", [5, 7], "1일 3회 매 식후 30분"),
    ]),
    "골다공증": ("M81", "상세불명의 골다공증", [
        ("포사맥스플러스디정", "1.0", "1", [28, 84], "주 1회 기상 직후 공복"),
        ("마시본정", "1.0", "2", [30, 90], "1일 2회 아침·저녁 식후 30분"),
    ]),
    "수면장애": ("G47", "수면장애", [
        ("스틸녹스정10mg", "1.0", "1", [7, 14, 28], "1일 1회 취침 직전"),
        ("자낙스정0.25mg", "1.0", "2", [7, 14], "1일 2회 아침·취침 전"),
    ]),
    "전립선증식증": ("N40", "전립선증식증", [
        ("하루날디정0.2mg", "1.0", "1", [30, 90], "1일 1회 저녁 식후 30분"),
        ("아보다트연질캡슐0.5mg", "1.0", "1", [30, 90], "1일 1회 아침 식후 30분"),
    ]),
    "철결핍빈혈": ("D50", "철결핍빈혈", [
        ("훼럼포라액", "1.0", "1", [14, 28, 30], "1일 1회 아침 공복 복용"),
        ("헤모큐캡슐", "1.0", "2", [28, 30], "1일 2회 아침·저녁 식전"),
    ]),
    "비타민결핍": ("E56", "기타 비타민 결핍", [
        ("삐콤씨정", "1.0", "1", [30, 60], "1일 1회 아침 식후 30분"),
        ("메가도스비타민디정", "1.0", "1", [30, 90], "1일 1회 아침 식후 30분"),
    ]),
    "불안장애": ("F41", "기타 불안장애", [
        ("자낙스정0.25mg", "1.0", "2", [14, 28], "1일 2회 아침·저녁 식후"),
        ("렉사프로정10mg", "1.0", "1", [28, 30], "1일 1회 아침 식후 30분"),
    ]),
    "기능성장애": ("K59", "기타 기능성 장 장애", [
        ("듀스파타린정135mg", "1.0", "3", [14, 28], "1일 3회 매 식전 30분"),
        ("포리부틴정100mg", "1.0", "3", [7, 14], "1일 3회 매 식후 30분"),
    ]),
    "비만": ("E66", "비만", [
        ("큐시미아캡슐7.5/46mg", "1.0", "1", [28, 30], "1일 1회 아침 식후"),
        ("제니칼캡슐120mg", "1.0", "3", [30, 90], "1일 3회 매 식중 또는 식후 1시간 이내"),
    ]),
}

BY_CLASS = {
    "underweight": ["철결핍빈혈", "위염", "감기", "갑상선기능저하", "비타민결핍",
                    "불안장애", "기능성장애", "기관지염"],
    "normal":      ["감기", "기관지염", "위식도역류", "등통증", "수면장애", "위염"],
    "overweight":  ["위식도역류", "등통증", "고혈압", "이상지질혈증", "감기", "수면장애"],
    "obese1":      ["고혈압", "이상지질혈증", "당뇨", "무릎관절증", "위식도역류", "등통증"],
    "obese2":      ["고혈압", "당뇨", "이상지질혈증", "무릎관절증", "통풍",
                    "수면장애", "비만"],
}

HOSPITALS = [
    ("연세미래의원", "31", "02", "3412", "7788"), ("한마음내과의원", "31", "02", "556", "1023"),
    ("서울참사랑의원", "31", "031", "8215", "4460"), ("굿모닝가정의학과의원", "31", "051", "742", "9930"),
    ("중앙제일병원", "11", "053", "421", "6070"), ("성모윌내과의원", "31", "062", "233", "5512"),
    ("푸른솔의원", "31", "032", "873", "2140"), ("새봄가정의학과의원", "31", "042", "635", "7719"),
    ("우리들정형외과의원", "31", "02", "2088", "3355"), ("한빛종합병원", "11", "055", "277", "8800"),
]
PHARMACIES = ["온누리약국", "연세참약국", "미래로약국", "건강한약국", "행복한약국",
              "365열린약국", "가족사랑약국", "중앙약국", "ه", "새싹약국"]
PHARMACIES = [x for x in PHARMACIES if all("가" <= c <= "힣" or c.isdigit() for c in x)]
DOCS_M = ["김성호", "이재현", "박정우", "최동民", "정민석", "강태훈", "조현진", "윤상철"]
DOCS_F = ["한지영", "오수민", "서예린", "신다혜", "권보라", "황미경", "안소영"]
DOCS = [d for d in DOCS_M + DOCS_F if all("가" <= c <= "힣" for c in d)]
PHARMS = ["김은주", "이한별", "박세훈", "최유진", "정소라", "장민호", "임채원", "송하늘"]


def build_rx(p, seed):
    """인물 p에 맞는 처방 내용을 만든다. 반환: 필드 dict (= ground truth)."""
    rnd = random.Random(seed)
    pool = list(BY_CLASS[p.cls_key])
    if p.age >= 65:
        pool += ["골다공증", "무릎관절증"]
        if p.sex == "M":
            pool += ["전립선증식증"]
    if p.age <= 25:
        pool = [c for c in pool if c not in ("골다공증", "전립선증식증", "통풍")]

    n_cond = rnd.choice([1, 1, 2, 2, 2, 3])
    conds = rnd.sample(pool, min(n_cond, len(pool)))

    drugs, codes = [], []
    for c in conds:
        code, dname, cand = CONDITIONS[c]
        codes.append(code)
        for nm, dose, freq, days, usage in rnd.sample(cand, min(len(cand), rnd.choice([1, 1, 2]))):
            drugs.append({"name": nm, "dose": dose, "freq": freq,
                          "days": str(rnd.choice(days)), "usage": usage})
    drugs = drugs[:6]

    hos = rnd.choice(HOSPITALS)
    issue = p.test_dt.date() + dt.timedelta(days=rnd.randint(0, 20))
    inj = rnd.random() < 0.18
    inj_rows = []
    if inj:
        inj_rows = [{"name": rnd.choice(["케토락신주30mg", "덱사메타손주5mg", "리도카인주2%"]),
                     "dose": "1.0", "freq": "1", "days": "1"}]

    lic_kind = rnd.choices(["의사", "한의사", "치과의사"], weights=[92, 5, 3])[0]
    valid_days = rnd.choice([3, 3, 7, 7, 14])
    disp_date = issue + dt.timedelta(days=rnd.randint(0, min(valid_days, 3)))
    max_days = max(int(d["days"]) for d in drugs)

    return {
        "보험종류": rnd.choices(["건강보험", "의료급여", "산업재해보험", "자동차보험"],
                            weights=[86, 8, 3, 3])[0],
        "요양기관기호": f"{hos[1]}{rnd.randint(100000, 999999)}",
        "발급연월일": issue,
        "발급번호": f"{rnd.randint(1, 9999)}",
        "환자성명": p.name,
        "주민등록번호": p.rrn,
        "의료기관명칭": hos[0],
        "전화번호": f"({hos[2]}) {hos[3]}-{hos[4]}",
        "팩스번호": f"({hos[2]}) {hos[3]}-{int(hos[4])+1:04d}",
        "질병분류기호": codes,
        "처방의료인성명": rnd.choice(DOCS),
        "면허종류": lic_kind,
        "면허번호": f"{rnd.randint(10000, 139999)}",
        "의약품": drugs,
        "주사제": inj_rows,
        "주사제구분": ("원내" if rnd.random() < 0.5 else "원외") if inj else None,
        "사용기간": str(valid_days),
        "조제시참고사항": rnd.choice(["", "", "", "복약지도 요망", "분할조제 가능",
                                "정제 분쇄 조제 요망"]),
        "조제기관명칭": rnd.choice(PHARMACIES),
        "조제약사성명": rnd.choice(PHARMS),
        "조제량": str(max_days),
        "조제연월일": disp_date,
        "변경내용": rnd.choice(["", "", "", "", "동일성분 대체조제(의사 사전동의)"]),
    }


CSS = """
*{margin:0;padding:0;box-sizing:border-box}
body{background:#fff}
.page{width:820px;height:1160px;background:#fff;font-family:%FONT%;color:#111;
      padding:34px 40px;position:relative;font-size:12.5px}
.tag{font-size:12.5px;margin-bottom:5px}
table{border-collapse:collapse;width:100%;table-layout:fixed}
td{border:1px solid #000;padding:2px 4px;font-size:12px;vertical-align:middle;height:26px}
.b0{border:none}
.title{text-align:center;font-size:17px;letter-spacing:5px;padding:5px 0}
.ins{font-size:12.5px;padding:2px 4px}
.ctr{text-align:center}
.vt{text-align:center;font-size:11.5px;padding:0;line-height:1.15;letter-spacing:0}
.fill{font-weight:600}
.sm{font-size:10.5px}
.xs{font-size:9.5px;color:#222}
.hd{text-align:center;font-size:11.5px;line-height:1.15}
.dot td{border-bottom:1px dotted #444}
.foot{position:absolute;right:40px;font-size:12px;margin-top:6px}
.circ{display:inline-block;border:1px solid #000;width:13px;height:13px;line-height:12px;
      text-align:center;font-size:9px;margin-right:1px;vertical-align:1px}
.sel{background:#000;color:#fff}
.box{display:inline-block;width:11px;height:11px;border:1px solid #000;vertical-align:-1px;
     position:relative;margin:0 2px}
.box.on:after{content:"✓";position:absolute;left:0;top:-6px;font-size:12px;font-weight:700}
.sig{font-family:'Noto Serif CJK KR',serif;font-style:italic;font-size:14px}
"""


def render_html(f):
    ins = ["건강보험", "의료급여", "산업재해보험", "자동차보험", "기타"]
    ins_html = ""
    for i, nm in enumerate(ins):
        on = "sel" if f["보험종류"] == nm else ""
        ins_html += f'<span class="circ {on}">{i+1}</span>{nm}'
    ins_html += "(&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;)"

    codes = f["질병분류기호"] + [""] * 5
    code_td = "".join(f'<td class="ctr fill">{c}</td>' for c in codes[:5])

    drows = ""
    drugs = f["의약품"]
    for i in range(6):
        d = drugs[i] if i < len(drugs) else None
        if d:
            drows += (f'<tr><td class="fill sm">{d["name"]}</td>'
                      f'<td class="ctr fill">{d["dose"]}</td>'
                      f'<td class="ctr fill">{d["freq"]}</td>'
                      f'<td class="ctr fill">{d["days"]}</td>'
                      f'<td class="fill sm">{d["usage"]}</td></tr>')
        elif i == 5:
            drows += ('<tr><td></td><td></td><td></td><td></td>'
                      '<td class="ctr sm">매 식(전, 간, 후)<br>시 분 복용</td></tr>')
        else:
            drows += "<tr><td></td><td></td><td></td><td></td><td></td></tr>"

    irows = ""
    inj = f["주사제"]
    for i in range(3):
        d = inj[i] if i < len(inj) else None
        if d:
            irows += (f'<tr><td class="fill sm">{d["name"]}</td>'
                      f'<td class="ctr fill">{d["dose"]}</td>'
                      f'<td class="ctr fill">{d["freq"]}</td>'
                      f'<td class="ctr fill">{d["days"]}</td></tr>')
        else:
            irows += "<tr><td></td><td></td><td></td><td></td></tr>"

    inb = "on" if f["주사제구분"] == "원내" else ""
    outb = "on" if f["주사제구분"] == "원외" else ""
    d0 = f["발급연월일"]
    d1 = f["조제연월일"]
    V = lambda s: "<br>".join(s)          # 세로 라벨 (writing-mode 대신 확실한 방식)

    cg = lambda *w: "<colgroup>" + "".join(f'<col style="width:{x}px">' for x in w) + "</colgroup>"

    return f"""<!doctype html><html lang="ko"><head><meta charset="utf-8">
<style>{CSS.replace('%FONT%', FONT)}</style></head><body><div class="page">
<div class="tag">[별지 제9호서식]</div>

<table><tr><td class="b0" style="border:1px solid #000;border-bottom:none">
   <div class="title">처방전</div>
   <div class="ins">{ins_html}</div>
   <div class="ins">요양기관기호: <span class="fill">{f['요양기관기호']}</span></div>
</td></tr></table>

<table style="border-top:none">{cg(26,124,212,24,96,258)}
 <tr>
  <td colspan="2">발급 연월일 및 번호</td>
  <td class="ctr fill">{d0.year} 년 {d0.month} 월 {d0.day} 일 - 제 {f['발급번호']} 호</td>
  <td rowspan="3" class="vt">{V('의료기관')}</td>
  <td>명칭</td>
  <td class="fill">{f['의료기관명칭']}</td>
 </tr>
 <tr>
  <td rowspan="2" class="vt">{V('환자')}</td>
  <td>성명</td>
  <td class="fill ctr">{f['환자성명']}</td>
  <td>전화번호</td><td class="fill">{f['전화번호']}</td>
 </tr>
 <tr>
  <td>주민등록번호</td>
  <td class="fill ctr">{f['주민등록번호']}</td>
  <td>팩스번호</td><td class="fill">{f['팩스번호']}</td>
 </tr>
</table>

<table style="border-top:none">{cg(26,46,46,46,46,46,78,150,78,178)}
 <tr>
  <td rowspan="2" class="vt">{V('질병분류기호')}</td>
  {code_td}
  <td rowspan="2" class="hd">처방<br>의료인의<br>성명</td>
  <td class="ctr fill">{f['처방의료인성명']} <span class="sig">(인)</span></td>
  <td>면허종류</td>
  <td class="ctr fill">{f['면허종류']}</td>
 </tr>
 <tr>
  <td colspan="5"></td>
  <td class="ctr sm">( 서명 또는 날인 )</td>
  <td>면허번호</td>
  <td class="ctr">제 <span class="fill">{f['면허번호']}</span> 호</td>
 </tr>
 <tr><td colspan="10" class="sm">※ 환자가 요구하면 질병분류기호를 적지 아니합니다.</td></tr>
</table>

<table style="border-top:none">{cg(250,86,62,74,268)}
 <tr>
  <td class="hd">처방 의약품의 명칭</td>
  <td class="hd">1회 투약량</td>
  <td class="hd">1일<br>투여<br>횟수</td>
  <td class="hd">총<br>투약일수</td>
  <td class="hd">용법</td>
 </tr>
 {drows}
 <tr><td colspan="4">&nbsp;</td><td class="ctr sm">조제 시 참고 사항</td></tr>
 <tr>
  <td colspan="4">주사제 처방명세(원 내 조제 <span class="box {inb}"></span>, 원 외 처방 <span class="box {outb}"></span>)</td>
  <td rowspan="4" class="fill sm" style="vertical-align:top;padding-top:5px">{f['조제시참고사항']}</td>
 </tr>
 {irows}
</table>

<table style="border-top:none">{cg(90,382,268)}
 <tr>
  <td>사용기간</td>
  <td>발급일부터 ( <span class="fill">{f['사용기간']}</span> )일간</td>
  <td>사용기간 내에 약국에 제출하여야 합니다.</td>
 </tr>
</table>

<table style="border-top:none">{cg(26,118,80,222,294)}
 <tr><td colspan="5" class="ctr" style="letter-spacing:2px">의약품 조제 명세</td></tr>
 <tr>
  <td rowspan="4" class="vt">{V('조제명세')}</td>
  <td class="hd">조제기관의<br>명칭</td>
  <td colspan="2" class="fill">{f['조제기관명칭']}</td>
  <td rowspan="4" class="sm" style="vertical-align:top;padding-top:4px">
    처방의 변경·수정·확인·<br>대체 시 그 내용 등<br><br>
    <span class="fill">{f['변경내용']}</span></td>
 </tr>
 <tr>
  <td>조제약사</td>
  <td>성명</td>
  <td class="fill">{f['조제약사성명']} <span class="sm">(서명 또는 인)</span></td>
 </tr>
 <tr>
  <td class="hd">조제량<br>(조제일수)</td>
  <td colspan="2" class="fill">{f['조제량']}</td>
 </tr>
 <tr>
  <td>조제연월일</td>
  <td colspan="2" class="fill">{d1.year}. {d1.month:02d}. {d1.day:02d}.</td>
 </tr>
</table>
<div class="foot">210㎜×297㎜[신문용지 54g/㎡(재활용품)]</div>
</div></body></html>"""
