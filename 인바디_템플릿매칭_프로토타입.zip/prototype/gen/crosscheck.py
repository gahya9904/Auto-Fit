# -*- coding: utf-8 -*-
"""
OCR 결과 교차검증 규칙 — 이 데이터셋의 핵심 활용처.

문서에 인쇄된 값들은 서로 수식으로 묶여 있다. 따라서 정답을 몰라도
'인식된 값끼리 앞뒤가 맞는지'만으로 오인식을 잡아낼 수 있다.
실제 서비스에서 사용자가 사진을 올렸을 때 그대로 쓰는 로직이다.

    검사 결과 예시
      LDL 이 TC-HDL-TG/5 와 다르다      → 세 값 중 하나가 오인식
      체수분+단백질+무기질 ≠ 제지방량     → 체성분표 오인식
      BMI ≠ 체중/신장²                  → 신장 또는 체중 오인식

사용:
    python3 gen/crosscheck.py --dataset dataset          # 정답으로 규칙 자체를 검증
    from crosscheck import check_inbody, check_checkup   # 파이프라인에 직접 사용
"""
import argparse
import json
import os

TOL = {"abs": 1.0, "rel": 0.02}


def _pos(*vals):
    """분모로 쓸 값들이 모두 유효한 양수인지. OCR이 0을 뱉으면 검산이 터진다."""
    return all(v is not None and abs(float(v)) > 1e-6 for v in vals)


def _bad(name, got, exp, tol_abs=1.0, tol_rel=0.02):
    if got is None or exp is None:
        return None
    tol = max(tol_abs, abs(exp) * tol_rel)
    if abs(got - exp) > tol:
        return f"{name}: 인식값 {got} vs 계산값 {exp:.1f} (허용 ±{tol:.1f})"
    return None


def check_inbody(v):
    """v: OCR로 뽑은 인바디 값 dict. 반환: 위반 목록(비어 있으면 통과)."""
    e = []
    g = v.get
    if all(g(k) is not None for k in ("체수분_L", "단백질_kg", "무기질_kg", "제지방량_kg")):
        e.append(_bad("제지방량 = 체수분+단백질+무기질",
                      g("제지방량_kg"), g("체수분_L") + g("단백질_kg") + g("무기질_kg"), 0.3))
    if all(g(k) is not None for k in ("제지방량_kg", "체지방_kg", "체중_kg")):
        e.append(_bad("체중 = 제지방량+체지방",
                      g("체중_kg"), g("제지방량_kg") + g("체지방_kg"), 0.3))
    if g("BMI") is not None and _pos(g("신장_cm")):
        e.append(_bad("BMI = 체중/신장²",
                      g("BMI"), g("체중_kg") / (g("신장_cm") / 100) ** 2, 0.3)
                 if g("체중_kg") is not None else None)
    if g("체지방률_pct") is not None and g("체지방_kg") is not None and _pos(g("체중_kg")):
        e.append(_bad("체지방률 = 체지방/체중",
                      g("체지방률_pct"), g("체지방_kg") / g("체중_kg") * 100, 0.6))
    if all(g(k) is not None for k in ("제지방량_kg", "기초대사량_kcal")):
        e.append(_bad("기초대사량 = 21.6×제지방량+370",
                      g("기초대사량_kcal"), 21.6 * g("제지방량_kg") + 370, 3))
    if all(g(k) is not None for k in ("세포내수분_L", "세포외수분_L", "체수분_L")):
        e.append(_bad("체수분 = 세포내+세포외",
                      g("체수분_L"), g("세포내수분_L") + g("세포외수분_L"), 0.3))
    if g("세포외수분비") is not None and g("세포외수분_L") is not None and _pos(g("체수분_L")):
        e.append(_bad("세포외수분비 = 세포외/체수분",
                      g("세포외수분비"), g("세포외수분_L") / g("체수분_L"), 0.006, 0))
    if all(g(k) is not None for k in ("체중조절_kg", "지방조절_kg", "근육조절_kg")):
        e.append(_bad("체중조절 = 지방조절+근육조절",
                      g("체중조절_kg"), g("지방조절_kg") + g("근육조절_kg"), 0.3))
    return [x for x in e if x]


def check_checkup(v, sex=None, age=None):
    """v: OCR로 뽑은 건강검진 결과통보서 값 dict."""
    e = []
    g = v.get
    tg, tc, hdl, ldl = g("중성지방_mg_dL"), g("총콜레스테롤_mg_dL"), \
        g("HDL콜레스테롤_mg_dL"), g("LDL콜레스테롤_mg_dL")
    if None not in (tg, tc, hdl, ldl) and tg < 400:
        e.append(_bad("LDL = TC-HDL-TG/5 (Friedewald)", ldl, tc - hdl - tg / 5, 2))
    if g("체질량지수") is not None and g("체중_kg") is not None and _pos(g("신장_cm")):
        e.append(_bad("BMI = 체중/신장²",
                      g("체질량지수"), g("체중_kg") / (g("신장_cm") / 100) ** 2, 0.3))
    cr, egfr = g("혈청크레아티닌_mg_dL"), g("eGFR")
    if egfr is not None and age and _pos(cr, age) and cr > 0:
        exp = 175 * (cr ** -1.154) * (age ** -0.203) * (1 if sex == "M" else 0.742)
        e.append(_bad("eGFR = MDRD(크레아티닌, 연령, 성별)", egfr, min(exp, 160), 2, 0.03))
    # 범위 상식 검사 — 자릿수 오인식을 잡는다
    RANGE = {"수축기혈압": (70, 250), "이완기혈압": (40, 150), "공복혈당_mg_dL": (40, 500),
             "총콜레스테롤_mg_dL": (80, 450), "중성지방_mg_dL": (20, 900),
             "HDL콜레스테롤_mg_dL": (15, 130), "LDL콜레스테롤_mg_dL": (20, 350),
             "혈색소_g_dL": (5, 22), "혈청크레아티닌_mg_dL": (0.2, 12),
             "eGFR": (5, 200), "AST_IU_L": (5, 600), "ALT_IU_L": (3, 600),
             "감마지티피_IU_L": (3, 800), "체질량지수": (10, 60), "허리둘레_cm": (45, 180)}
    for k, (lo, hi) in RANGE.items():
        x = g(k)
        if x is not None and not (lo <= x <= hi):
            e.append(f"{k}: {x} 은(는) 생리학적 범위({lo}~{hi})를 벗어남 — 자릿수 오인식 의심")
    if None not in (g("수축기혈압"), g("이완기혈압")) and g("수축기혈압") <= g("이완기혈압"):
        e.append(f"수축기({g('수축기혈압')}) ≤ 이완기({g('이완기혈압')}) — 두 값이 뒤바뀜")
    return [x for x in e if x]


def _demo(dataset):
    gt = json.load(open(os.path.join(dataset, "labels", "ground_truth.json"),
                        encoding="utf-8"))
    seen, ok, ng = set(), 0, 0
    for r in gt["records"]:
        key = (r["person_id"], r["doc_type"])
        if key in seen:
            continue
        seen.add(key)
        f = r["fields"]
        if r["doc_type"] == "inbody":
            v = check_inbody(f)
        elif r["doc_type"] == "checkup":
            sx = "M" if r["subject"]["성별"] == "남성" else "F"
            v = check_checkup(f, sx, r["subject"]["연령"])
        else:
            continue
        ok += not v
        ng += bool(v)
        for m in v[:3]:
            print(f"  [{r['doc_type']}/{r['person_id']}] {m}")
    print(f"\n정답값에 규칙 적용: 통과 {ok} / 위반 {ng}")
    print("→ 위반 0이면 규칙이 정답과 모순되지 않는다는 뜻. "
          "이제 OCR 출력에 같은 함수를 걸면 오인식이 걸러진다.")

    # 일부러 오인식을 주입해 규칙이 실제로 잡는지 확인
    print("\n오인식 주입 테스트")
    for r in gt["records"]:
        if r["doc_type"] != "checkup":
            continue
        sx = "M" if r["subject"]["성별"] == "남성" else "F"
        bad = dict(r["fields"])
        bad["HDL콜레스테롤_mg_dL"] = bad["HDL콜레스테롤_mg_dL"] * 10   # 38 → 380
        got = check_checkup(bad, sx, r["subject"]["연령"])
        print(f"  HDL 자릿수 오인식 주입 → 탐지 {len(got)}건")
        for m in got:
            print(f"    · {m}")
        break
    for r in gt["records"]:
        if r["doc_type"] != "inbody":
            continue
        bad = dict(r["fields"])
        bad["단백질_kg"] = bad["단백질_kg"] + 3.0                      # 7.3 → 10.3
        got = check_inbody(bad)
        print(f"  단백질 오인식 주입 → 탐지 {len(got)}건")
        for m in got:
            print(f"    · {m}")
        break


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", default="dataset")
    _demo(ap.parse_args().dataset)
