# -*- coding: utf-8 -*-
"""
생성 결과 검증 — 노이즈 프리셋별 OCR 난이도 베이스라인.

Tesseract(kor+eng)로 각 이미지를 읽고, ground truth의 핵심 필드 값이
인식 결과에 등장하는지 확인해 프리셋별 필드 재현율을 낸다.
이 수치 자체가 '노이즈가 실제로 OCR을 얼마나 어렵게 만드는가'의 증거다.
"""
import os
import re
import sys
import json
import argparse
from collections import defaultdict
from PIL import Image
import pytesseract

def ocr(img, lang, psm, upscale):
    if upscale > 1.01:
        img = img.resize((int(img.width * upscale), int(img.height * upscale)),
                         Image.LANCZOS)
    return pytesseract.image_to_string(img, lang=lang, config=f"--oem 1 --psm {psm}")


def norm(s):
    return re.sub(r"[\s,]", "", str(s))


def crit_values(rec):
    f = rec["fields"]
    if rec["doc_type"] == "inbody":
        return {
            "신장": f"{f['신장_cm']:.1f}", "연령": str(f["연령"]),
            "체중": f"{f['체중_kg']:.1f}", "골격근량": f"{f['골격근량_kg']:.1f}",
            "체지방": f"{f['체지방_kg']:.1f}", "BMI": f"{f['BMI']:.1f}",
            "체지방률": f"{f['체지방률_pct']:.1f}", "인바디점수": str(f["인바디점수"]),
            "기초대사량": str(f["기초대사량_kcal"]), "제지방량": f"{f['제지방량_kg']:.1f}",
            "세포외수분비": f"{f['세포외수분비']:.3f}", "SMI": f"{f['SMI_kg_m2']:.1f}",
        }
    out = {
        "요양기관기호": f["요양기관기호"], "환자성명": f["환자성명"],
        "주민등록번호": f["주민등록번호"], "의료기관명칭": f["의료기관명칭"],
        "면허번호": f["면허번호"], "사용기간": f["사용기간"],
        "조제기관명칭": f["조제기관명칭"], "조제약사": f["조제약사성명"],
    }
    for i, d in enumerate(f["의약품"]):
        out[f"약품{i+1}_명칭"] = d["name"]
        out[f"약품{i+1}_투약일수"] = d["days"]
    for i, c in enumerate(f["질병분류기호"]):
        out[f"상병코드{i+1}"] = c
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", default="dataset")
    ap.add_argument("--sample", type=int, default=4, help="프리셋·문서종류별 표본 수")
    ap.add_argument("--lang", default="kor+eng")
    ap.add_argument("--psm", type=int, default=6)
    ap.add_argument("--upscale", type=float, default=1.0,
                    help="OCR 전 확대 배율. 2.0이면 작은 숫자 인식률이 크게 오른다")
    a = ap.parse_args()

    gt = json.load(open(os.path.join(a.dataset, "labels", "ground_truth.json"),
                        encoding="utf-8"))
    buckets = defaultdict(list)
    for r in gt["records"]:
        buckets[(r["doc_type"], r["noise_preset"])].append(r)

    stats = defaultdict(lambda: [0, 0])
    per_field = defaultdict(lambda: defaultdict(lambda: [0, 0]))
    print(f"{'문서':8s} {'프리셋':17s} {'필드재현율':>10s}   표본")
    print("-" * 56)

    for doc in ("inbody", "rx"):
        for preset in gt["presets"]:
            recs = buckets[(doc, preset)][:: max(1, len(buckets[(doc, preset)]) // a.sample)][:a.sample]
            hit = tot = 0
            for r in recs:
                img = Image.open(os.path.join(a.dataset, r["image"]))
                txt = norm(ocr(img, a.lang, a.psm, a.upscale))
                for k, v in crit_values(r).items():
                    ok = norm(v) in txt
                    hit += ok
                    tot += 1
                    kk = re.sub(r"\d+", "N", k)
                    per_field[doc][kk][0] += ok
                    per_field[doc][kk][1] += 1
            stats[(doc, preset)] = [hit, tot]
            rate = hit / tot * 100 if tot else 0
            print(f"{doc:8s} {preset:17s} {rate:9.1f}%   n={len(recs)}")

    print("\n필드별 재현율 (전 프리셋 합산)")
    print("-" * 56)
    for doc in ("inbody", "rx"):
        rows = sorted(per_field[doc].items(), key=lambda x: x[1][0] / max(1, x[1][1]))
        for k, (h, t) in rows:
            print(f"  {doc:7s} {k:18s} {h/max(1,t)*100:5.1f}%  ({h}/{t})")

    out = {f"{d}/{p}": {"hit": v[0], "total": v[1],
                        "recall": round(v[0] / v[1] * 100, 1) if v[1] else 0}
           for (d, p), v in stats.items()}
    with open(os.path.join(a.dataset, "labels", "ocr_baseline.json"), "w",
              encoding="utf-8") as fp:
        json.dump(out, fp, ensure_ascii=False, indent=1)
    print("\n→ labels/ocr_baseline.json 저장")


if __name__ == "__main__":
    main()
