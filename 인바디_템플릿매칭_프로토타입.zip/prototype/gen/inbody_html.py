# -*- coding: utf-8 -*-
"""InBody 770S 결과지 HTML 재현 — 빈 템플릿 + 값 주입."""

FONT = "'Noto Sans CJK KR','Noto Sans KR',sans-serif"


def axis_pos(ticks, value):
    """구간별 등간격(piecewise-linear) 축. 실제 InBody 눈금 방식."""
    n = len(ticks)
    if value <= ticks[0]:
        return 0.0
    if value >= ticks[-1]:
        return 1.0
    for i in range(n - 1):
        a, b = ticks[i], ticks[i + 1]
        if a <= value <= b:
            seg = (value - a) / (b - a) if b != a else 0
            return (i + seg) / (n - 1)
    return 1.0


def _ticks_html(ticks, fmt="{:g}"):
    n = len(ticks)
    out = []
    for i, t in enumerate(ticks):
        left = i / (n - 1) * 100
        out.append(f'<span class="tk" style="left:{left:.3f}%">{fmt.format(t)}</span>')
    return "".join(out)


def _grid_html(ticks):
    n = len(ticks)
    return "".join(
        f'<i style="left:{i/(n-1)*100:.3f}%"></i>' for i in range(1, n - 1)
    )


def _val_style(p):
    """막대 끝이 우측에 붙으면 값을 막대 안쪽에 우측정렬 — 옆 칸 침범 방지."""
    if p >= 78:
        return f'left:{p:.3f}%;transform:translateX(-100%);padding-right:4px;color:#fff'
    return f'left:{p:.3f}%'


def bar_row(label, unit, ticks, value, disp, fmt="{:g}", extra="", fid=None):
    p = axis_pos(ticks, value) * 100
    return f"""
    <div class="brow">
      <div class="blab"><b>{label}</b><span class="u">{unit}</span></div>
      <div class="btrack">
        <div class="tks">{_ticks_html(ticks, fmt)}</div>
        <div class="tr">{_grid_html(ticks)}<div class="fill" style="width:{p:.3f}%"></div>
          <div class="bval"{(' data-f="%s"' % fid) if fid else ''} style="{_val_style(p)}">{disp}</div>
        </div>
      </div>{extra}
    </div>"""


def band_header(ticks, cuts=(2, 4), labels=("표준이하", "표준", "표준이상"), right=""):
    n = len(ticks) - 1
    w = [cuts[0] / n * 100, (cuts[1] - cuts[0]) / n * 100, (n - cuts[1]) / n * 100]
    cells = "".join(f'<div class="bh" style="width:{w[i]:.3f}%">{labels[i]}</div>'
                    for i in range(3))
    return f'<div class="brow bhrow"><div class="blab"></div><div class="btrack bhwrap">{cells}</div>{right}</div>'


SEGS = [("RA", "오른팔", "Right Arm"), ("LA", "왼팔", "Left Arm"), ("TR", "몸통", "Trunk"),
        ("RL", "오른다리", "Right Leg"), ("LL", "왼다리", "Left Leg")]


def _history_svg(hist, key, fmt, w=470, h=52):
    n = len(hist)
    vals = [r[key] for r in hist]
    lo, hi = min(vals), max(vals)
    if hi - lo < 1e-9:
        lo, hi = lo - 1, hi + 1
    pad = (hi - lo) * 0.35
    lo, hi = lo - pad, hi + pad
    pts, labs = [], []
    for i, v in enumerate(vals):
        x = 26 + i * (w - 46) / (n - 1)
        y = h - 12 - (v - lo) / (hi - lo) * (h - 30)
        pts.append((x, y))
        labs.append(f'<text x="{x:.1f}" y="{y-6:.1f}" class="hv">{fmt.format(v)}</text>')
    poly = " ".join(f"{x:.1f},{y:.1f}" for x, y in pts)
    dots = "".join(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="2.1"/>' for x, y in pts)
    return (f'<svg viewBox="0 0 {w} {h}" class="hsvg">'
            f'<polyline points="{poly}" fill="none" stroke="#111" stroke-width="1.1"/>'
            f'{dots}{"".join(labs)}</svg>')


def _vfa_svg(age, vfa, w=248, h=132):
    x0, y0, x1, y1 = 34, 8, w - 8, h - 20
    def px(a): return x0 + (a - 10) / 80 * (x1 - x0)
    def py(v): return y1 - (v - 0) / 230 * (y1 - y0)
    yl = "".join(f'<text x="{x0-5}" y="{py(v)+3:.1f}" class="ax" text-anchor="end">{v}</text>'
                 f'<line x1="{x0}" y1="{py(v):.1f}" x2="{x1}" y2="{py(v):.1f}" class="gl"/>'
                 for v in (50, 100, 150, 200))
    xl = "".join(f'<text x="{px(a):.1f}" y="{y1+12}" class="ax" text-anchor="middle">{a}</text>'
                 for a in (20, 40, 60, 80))
    blob = (f'<path d="M {px(18):.1f},{py(58):.1f} C {px(30):.1f},{py(28):.1f} '
            f'{px(62):.1f},{py(40):.1f} {px(86):.1f},{py(96):.1f} '
            f'C {px(88):.1f},{py(150):.1f} {px(52):.1f},{py(146):.1f} '
            f'{px(24):.1f},{py(118):.1f} Z" fill="#e2e2e2"/>')
    mx = px(min(max(age, 14), 86))
    my = min(max(py(min(vfa, 218)), y0 + 12), y1 - 6)
    near_r = mx > x1 - 46
    lx, anc = (mx - 7, "end") if near_r else (mx + 7, "start")
    mark = (f'<line x1="{mx-9:.1f}" y1="{my:.1f}" x2="{mx+9:.1f}" y2="{my:.1f}" stroke="#111" stroke-width="1.3"/>'
            f'<line x1="{mx:.1f}" y1="{my-9:.1f}" x2="{mx:.1f}" y2="{my+9:.1f}" stroke="#111" stroke-width="1.3"/>'
            f'<text x="{lx:.1f}" y="{my-5:.1f}" class="vfv" data-f="vfa" text-anchor="{anc}">{vfa:g}</text>')
    return (f'<svg viewBox="0 0 {w} {h}" class="vsvg">{blob}{yl}{xl}'
            f'<line x1="{x0}" y1="{y0}" x2="{x0}" y2="{y1}" class="axl"/>'
            f'<line x1="{x0}" y1="{y1}" x2="{x1}" y2="{y1}" class="axl"/>'
            f'<text x="{x0-2}" y="{y0+2}" class="ax">VFA(cm²)</text>'
            f'<text x="{x1}" y="{y1+12}" class="ax" text-anchor="end">나이</text>{mark}</svg>')


def _imp_svg(imp, w=248, h=104):
    x0, y0, x1, y1 = 40, 8, w - 8, h - 16
    order = ["RA", "LA", "TR", "RL", "LL"]
    freqs = [5, 50, 250, 500, 1000]
    allv = [v for s in order for v in imp[s]]
    lo, hi = min(allv) * 0.9, max(allv) * 1.08
    def px(i): return x0 + i * (x1 - x0) / (len(order) - 1)
    def py(v): return y1 - (v - lo) / (hi - lo) * (y1 - y0)
    lines = ""
    for fi in range(len(freqs)):
        pts = " ".join(f"{px(si):.1f},{py(imp[s][fi]):.1f}" for si, s in enumerate(order))
        lines += f'<polyline points="{pts}" fill="none" stroke="#333" stroke-width="0.7"/>'
    yl = "".join(f'<text x="{x0-4}" y="{y0+6+i*(y1-y0-4)/4:.1f}" class="ax" text-anchor="end">{f}</text>'
                 for i, f in enumerate(freqs))
    xl = "".join(f'<text x="{px(i):.1f}" y="{y1+11}" class="ax" text-anchor="middle">{s}</text>'
                 for i, s in enumerate(order))
    return (f'<svg viewBox="0 0 {w} {h}" class="isvg">{lines}{yl}{xl}'
            f'<text x="{x0-10}" y="{y1+11}" class="ax" text-anchor="end">kHz</text>'
            f'<line x1="{x0}" y1="{y0}" x2="{x0}" y2="{y1}" class="axl"/>'
            f'<line x1="{x0}" y1="{y1}" x2="{x1}" y2="{y1}" class="axl"/></svg>')


CSS = """
*{margin:0;padding:0;box-sizing:border-box}
body{background:#fff}
.page{width:840px;height:1208px;background:#fff;font-family:%FONT%;color:#111;
      padding:14px 16px 8px;position:relative}
.hdr{display:flex;align-items:flex-start;justify-content:space-between;border-bottom:2.5px solid #8b1a2b;padding-bottom:5px}
.logo{font-size:37px;font-weight:900;letter-spacing:-1.6px;font-family:Arial,Helvetica,sans-serif}
.model{font-size:13px;font-weight:700;margin-top:16px}
.rlogo{text-align:right}.rlogo .l2{font-size:20px;font-weight:900;font-family:Arial,Helvetica,sans-serif}
.rlogo .u2{font-size:9.5px;color:#333}
.idbar{display:flex;border:1px solid #444;border-top:none;margin-bottom:7px}
.idbar div{border-right:1px solid #444;padding:3px 8px;font-size:11px}
.idbar div:last-child{border-right:none}
.idbar .k{font-size:9.5px;color:#333;display:block}
.idbar .v{font-size:12px;font-weight:600}
.wrap{display:flex;gap:9px}
.col-l{width:534px}.col-r{width:262px;border-left:1px solid #bbb;padding-left:9px}
.sec{margin-bottom:7px}
.st{font-size:12.5px;font-weight:800;border-bottom:1.6px solid #333;padding-bottom:1px;margin-bottom:3px}
.st span{font-size:8.5px;font-weight:400;color:#444;margin-left:4px}
.rt{font-size:11px;font-weight:700;margin:5px 0 2px;border-bottom:1px solid #666;padding-bottom:1px}
.rt span{font-size:7.5px;font-weight:400;color:#444;margin-left:3px}
table.bc{width:100%;border-collapse:collapse;font-size:9px}
table.bc td,table.bc th{border:1px solid #555;padding:1px 2px;text-align:center;vertical-align:middle}
table.bc th{background:#7a8794;color:#fff;font-size:8.5px;font-weight:600;padding:2px}
.nm{text-align:left!important;font-size:9px;font-weight:600;padding-left:4px!important;width:78px}
.nm i{display:block;font-style:normal;font-size:6.8px;color:#555;font-weight:400}
.uu{width:26px;font-size:8px;color:#333}
.big{font-size:14px;font-weight:700;line-height:1.05}
.rng{font-size:7.2px;color:#333;display:block}
.brow{display:flex;align-items:flex-end;margin-bottom:1px}
.blab{width:80px;font-size:8.8px;font-weight:600;flex:none;padding-bottom:1px}
.blab .u{font-size:7.5px;color:#444;margin-left:2px;font-weight:400}
.blab i{display:block;font-style:normal;font-size:6.6px;color:#555;font-weight:400}
.btrack{flex:1;position:relative}
.tks{position:relative;height:9px}
.tk{position:absolute;transform:translateX(-50%);font-size:6.6px;color:#222;white-space:nowrap}
.tr{position:relative;height:13px;background:#dcdcdc;border:0.5px solid #b6b6b6}
.tr i{position:absolute;top:0;bottom:0;width:0.5px;background:#fff}
.fill{position:absolute;left:0;top:0;bottom:0;background:#1c1c1c}
.bval{position:absolute;top:0.5px;font-size:10.5px;font-weight:700;padding-left:3px;white-space:nowrap;color:#000}
.bhrow{margin-bottom:1.5px}
.bhwrap{display:flex}
.bh{background:#7a8794;color:#fff;font-size:8px;text-align:center;border-right:1px solid #fff;padding:1px 0}
.bh:last-child{border-right:none}
.ecw{width:44px;flex:none;text-align:center;font-size:9.5px;font-weight:700;padding-bottom:1px}
.ecwh{width:44px;flex:none;text-align:center;font-size:7px;color:#333}
.hrow{display:flex;align-items:center;border-bottom:1px dotted #ccc}
.hlab{width:74px;font-size:8.6px;font-weight:600;flex:none}
.hlab i{display:block;font-style:normal;font-size:6.4px;color:#555;font-weight:400}
.hsvg{flex:1;height:52px}
.hv{font-size:8.2px;text-anchor:middle;fill:#111;font-weight:600}
.hdates{display:flex;font-size:6.3px;color:#333;margin-left:74px;justify-content:space-between;padding:1px 8px 0}
.hdates span{text-align:center;line-height:1.15}
.score{text-align:center;margin:2px 0 4px}
.score .n{font-size:34px;font-weight:800;letter-spacing:-1px}
.score .d{font-size:11px;font-weight:600}
.note{font-size:7px;color:#333;line-height:1.25;margin-top:1px}
.vsvg,.isvg{width:100%}
.ax{font-size:6.8px;fill:#333}.gl{stroke:#e6e6e6;stroke-width:0.5}.axl{stroke:#777;stroke-width:0.7}
.vfv{font-size:9px;font-weight:700;fill:#000}
.kv{display:flex;justify-content:space-between;font-size:9.4px;padding:1.2px 0;border-bottom:1px dotted #ddd}
.kv b{font-weight:700}
.kv .k{color:#111}
.bal{display:flex;align-items:center;font-size:8.4px;padding:1.3px 0}
.bal .k{width:52px;font-weight:600}
.bal label{flex:1;white-space:nowrap}
.ck{display:inline-block;width:7px;height:7px;border:1px solid #333;margin-right:2px;vertical-align:-1px;position:relative}
.ck.on:after{content:"✓";position:absolute;left:0;top:-4px;font-size:8px;font-weight:700}
.sfat{display:flex;align-items:center;font-size:8.6px;padding:1px 0}
.sfat .k{width:40px;font-weight:600}
.sfat .kg{width:44px;text-align:right;font-size:8.2px}
.sfat .mb{flex:1;height:8px;background:#e4e4e4;position:relative;margin:0 4px}
.sfat .mb i{position:absolute;left:0;top:0;bottom:0;background:#222}
.sfat .pv{width:44px;text-align:right;font-weight:700;font-size:9px}
.foot{position:absolute;bottom:5px;right:16px;font-size:6.2px;color:#555}
.tri{font-size:7px;color:#333;text-align:right;margin-bottom:1px}
"""


def render_html(p):
    slm = round(p.tbw + p.protein + 0.15 * p.mineral, 1)
    fs = p.ffm_std
    ffm_lo, ffm_hi = fs * 0.90, fs * 1.10
    r = lambda a, b, d=1: f"({a:.{d}f}~{b:.{d}f})"
    sex_k = "남성" if p.sex == "M" else "여성"

    # ---- 체성분분석 표
    bc = f"""
    <table class="bc">
      <tr><th></th><th></th><th>측정치</th><th>체수분</th><th>근육량</th><th>제지방량</th><th>체중</th></tr>
      <tr>
        <td class="nm">체수분<i>Total Body Water</i></td><td class="uu">(L)</td>
        <td><span class="big" data-f="tbw">{p.tbw:.1f}</span><span class="rng">{r(p.tbw/max(p.ffm,.1)*ffm_lo, p.tbw/max(p.ffm,.1)*ffm_hi)}</span></td>
        <td rowspan="1"><span class="big">{p.tbw:.1f}</span></td>
        <td rowspan="2"><span class="big" data-f="slm">{slm:.1f}</span><span class="rng">{r(ffm_lo*0.945, ffm_hi*0.945)}</span></td>
        <td rowspan="3"><span class="big" data-f="ffm">{p.ffm:.1f}</span><span class="rng">{r(ffm_lo, ffm_hi)}</span></td>
        <td rowspan="4"><span class="big" data-f="wt">{p.weight:.1f}</span><span class="rng">{r(p.w_std*0.85, p.w_std*1.15)}</span></td>
      </tr>
      <tr>
        <td class="nm">단백질<i>Protein</i></td><td class="uu">(kg)</td>
        <td><span class="big" data-f="pro">{p.protein:.1f}</span><span class="rng">{r(p.protein/max(p.ffm,.1)*ffm_lo, p.protein/max(p.ffm,.1)*ffm_hi)}</span></td>
        <td rowspan="3" style="font-size:6.5px;color:#555">non-osseous</td>
      </tr>
      <tr>
        <td class="nm">무기질<i>Minerals</i></td><td class="uu">(kg)</td>
        <td><span class="big" data-f="min">{p.mineral:.2f}</span><span class="rng">{r(p.mineral/max(p.ffm,.1)*ffm_lo, p.mineral/max(p.ffm,.1)*ffm_hi, 2)}</span></td>
      </tr>
      <tr>
        <td class="nm">체지방<i>Body Fat Mass</i></td><td class="uu">(kg)</td>
        <td><span class="big" data-f="bfm">{p.bfm:.1f}</span><span class="rng">{r(p.bfm_std*0.868, p.bfm_std*1.39)}</span></td>
      </tr>
    </table>"""

    # ---- 골격근·지방분석
    tw = [55, 70, 85, 100, 115, 130, 145, 160, 175, 190, 205]
    tm = [70, 80, 90, 100, 110, 120, 130, 140, 150, 160, 170]
    tf = [40, 60, 80, 100, 160, 220, 280, 340, 400, 460, 520]
    mf = band_header(tw) + \
        bar_row("체중", "(kg)", tw, p.weight / p.w_std * 100, f"{p.weight:.1f}", fid="wt_bar") + \
        bar_row("골격근량", "(kg)", tm, p.smm / p.smm_std * 100, f"{p.smm:.1f}", fid="smm") + \
        bar_row("체지방량", "(kg)", tf, p.bfm / p.bfm_std * 100, f"{p.bfm:.1f}", fid="bfm_bar")

    # ---- 비만분석
    tb = [10.0, 15.0, 18.5, 21.0, 23.0, 30.0, 35.0, 40.0, 45.0, 50.0, 55.0]
    tp = ([0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50] if p.sex == "M"
          else [8, 13, 18, 23, 28, 33, 38, 43, 48, 53, 58])
    ob = band_header(tb) + \
        bar_row("B M I", "(kg/m²)", tb, p.bmi, f"{p.bmi:.1f}", fmt="{:.1f}", fid="bmi") + \
        bar_row("체지방률", "(%)", tp, p.pbf, f"{p.pbf:.1f}", fmt="{:.1f}", fid="pbf")

    # ---- 부위별 근육
    ta = [40, 60, 80, 100, 120, 140, 160, 180, 200]
    tl = [70, 80, 90, 100, 110, 120, 130, 140, 150]
    sl = band_header(ta, cuts=(2, 4), right='<div class="ecwh">세포외<br>수분비</div>')
    for k, ko, en in SEGS:
        ticks = ta if k in ("RA", "LA") else tl
        kg = p.lean[k]
        kgs = f"{kg:.2f}" if k != "TR" else f"{kg:.1f}"
        sl += bar_row(f"{ko}", "(kg)", ticks, p.lean_pct[k], kgs,
                      extra=f'<div class="ecw">{p.seg_ecwr[k]:.3f}</div>')
        pos = axis_pos(ticks, p.lean_pct[k]) * 100
        sl += (f'<div class="brow"><div class="blab" style="font-size:7.6px">'
               f'<i>{en}</i> (%)</div><div class="btrack"><div class="tr" style="height:11px">'
               f'{_grid_html(ticks)}<div class="fill" style="width:{pos:.3f}%"></div>'
               f'<div class="bval" style="{_val_style(pos)};font-size:9px">{p.lean_pct[k]:.1f}</div>'
               f'</div></div><div class="ecw"></div></div>')

    # ---- 세포외수분비
    te = [0.320, 0.340, 0.360, 0.380, 0.390, 0.400, 0.410, 0.420, 0.430, 0.440, 0.450]
    ec = band_header(te) + bar_row("세포외수분비", "", te, p.ecw_ratio,
                                   f"{p.ecw_ratio:.3f}", fmt="{:.3f}", fid="ecwr")

    # ---- 신체변화
    h = p.history
    hist = ""
    for lab, en, key, fmt in [("체중", "Weight", "weight", "{:.1f}"),
                              ("골격근량", "Skeletal Muscle Mass", "smm", "{:.1f}"),
                              ("체지방률", "Percent Body Fat", "pbf", "{:.1f}"),
                              ("세포외수분비", "ECW Ratio", "ecwr", "{:.3f}")]:
        hist += (f'<div class="hrow"><div class="hlab">{lab}<i>{en}</i></div>'
                 f'{_history_svg(h, key, fmt)}</div>')
    dates = "".join(f'<span>{x["date"].strftime("%y.%m.%d")}<br>{x["date"].strftime("%H:%M")}</span>'
                    for x in h)

    # ---- 우측
    bal = ""
    for k, v in p.balance.items():
        opts = ""
        for o in ("균형", "약한불균형", "심한불균형"):
            on = "on" if v == o else ""
            opts += f'<label><span class="ck {on}"></span>{o}</label>'
        bal += f'<div class="bal"><div class="k">{k}</div>{opts}</div>'

    sfat = '<div class="tri">▼ &nbsp;— &nbsp;▲</div>'
    for k, ko, _ in SEGS:
        w_ = min(100.0, p.fat_pct[k] / 600 * 100)
        sfat += (f'<div class="sfat"><div class="k">{ko}</div>'
                 f'<div class="kg">( {p.fat[k]:.1f}kg )</div>'
                 f'<div class="mb"><i style="width:{w_:.1f}%"></i></div>'
                 f'<div class="pv">{p.fat_pct[k]:.1f}%</div></div>')

    return f"""<!doctype html><html lang="ko"><head><meta charset="utf-8">
<style>{CSS.replace('%FONT%', FONT)}</style></head><body><div class="page">

<div class="hdr">
  <div><div class="logo">InBody</div></div>
  <div class="model">[InBody770S]</div>
  <div class="rlogo"><div class="l2">InBody</div><div class="u2">inbody.com</div></div>
</div>
<div class="idbar">
  <div style="width:150px"><span class="k">회원번호</span><span class="v">{p.member_no}</span></div>
  <div style="width:110px"><span class="k">신장</span><span class="v"><span data-f="ht">{p.height:.1f}</span>cm</span></div>
  <div style="width:78px"><span class="k">연령</span><span class="v" data-f="age">{p.age}</span></div>
  <div style="width:88px"><span class="k">성별</span><span class="v">{sex_k}</span></div>
  <div style="flex:1"><span class="k">검사일시</span><span class="v">{p.test_dt.strftime('%Y.%m.%d. %H : %M')}</span></div>
</div>

<div class="wrap">
 <div class="col-l">
  <div class="sec"><div class="st">체성분분석<span>Body Composition Analysis</span></div>{bc}</div>
  <div class="sec"><div class="st">골격근·지방분석<span>Muscle-Fat Analysis</span></div>{mf}</div>
  <div class="sec"><div class="st">비만분석<span>Obesity Analysis</span></div>{ob}</div>
  <div class="sec"><div class="st">부위별근육분석<span>Segmental Lean Analysis</span></div>{sl}</div>
  <div class="sec"><div class="st">세포외수분비분석<span>ECW Ratio Analysis</span></div>{ec}</div>
  <div class="sec"><div class="st">신체변화<span>Body Composition History</span></div>{hist}
    <div class="hdates">{dates}</div></div>
 </div>

 <div class="col-r">
  <div class="rt">인바디점수<span>InBody Score</span></div>
  <div class="score"><span class="n" data-f="score">{p.score}</span><span class="d"> / 100 점</span></div>
  <div class="note">* 체성분 종합점수입니다. 근육이 매우 많을 경우 100점을 넘을 수 있습니다.</div>

  <div class="rt">내장지방단면적<span>Visceral Fat Area</span></div>
  {_vfa_svg(p.age, p.vfa)}

  <div class="rt">체중조절<span>Weight Control</span></div>
  <div class="kv"><span class="k">적정체중</span><b><span data-f="idw">{p.ideal_weight:.1f}</span> kg</b></div>
  <div class="kv"><span class="k">체중조절</span><b><span data-f="wctl">{p.w_ctrl:+.1f}</span> kg</b></div>
  <div class="kv"><span class="k">지방조절</span><b><span data-f="fctl">{p.f_ctrl:+.1f}</span> kg</b></div>
  <div class="kv"><span class="k">근육조절</span><b><span data-f="mctl">{p.m_ctrl:+.1f}</span> kg</b></div>

  <div class="rt">신체균형평가<span>Body Balance Evaluation</span></div>
  {bal}

  <div class="rt">부위별체지방분석<span>Segmental Fat Analysis</span></div>
  {sfat}

  <div class="rt">연구항목<span>Research Parameters</span></div>
  <div class="kv"><span class="k">세포내수분</span><b><span data-f="icw">{p.icw:.1f}</span> L</b><span style="font-size:7.5px">({p.icw*0.94:.1f}~{p.icw*1.12:.1f})</span></div>
  <div class="kv"><span class="k">세포외수분</span><b><span data-f="ecw">{p.ecw:.1f}</span> L</b><span style="font-size:7.5px">({p.ecw*0.92:.1f}~{p.ecw*1.10:.1f})</span></div>
  <div class="kv"><span class="k">기초대사량</span><b><span data-f="bmr">{p.bmr}</span> kcal</b><span style="font-size:7.5px">({p.bmr_lo}~{p.bmr_hi})</span></div>
  <div class="kv"><span class="k">SMI</span><b><span data-f="smi">{p.smi:.1f}</span> kg/m²</b></div>

  <div class="rt">전신 위상각<span>Whole Body Phase Angle</span></div>
  <div class="kv"><span class="k">φ(°)50kHz</span><b><span data-f="pha">{p.phase_angle:.1f}</span> °</b></div>

  <div class="rt">임피던스<span>Impedance</span></div>
  {_imp_svg(p.impedance)}
  <div style="font-size:6.2px;color:#444">Z(Ω) &nbsp; [000/000/000]</div>
 </div>
</div>
<div class="foot">Copyright ©1996~ by InBody Co.,Ltd. All rights reserved.</div>
</div></body></html>"""
