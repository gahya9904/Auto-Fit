# -*- coding: utf-8 -*-
"""
인바디 770S 템플릿 좌표 추출.

서식이 고정이므로 '어느 위치에 어떤 값이 인쇄되는지'를 한 번만 정해두면 된다.
여기서는 서식 HTML의 DOM에서 각 값 요소의 바운딩박스를 직접 읽어 좌표를 만든다.

※ 실제 인바디 용지를 다룰 때는 이 과정을 대신해
   기종별로 결과지 한 장을 스캔해 필드 위치를 한 번 측정해 두면 된다.
   방법(고정 좌표에서 값을 읽는다)은 동일하다.
"""
import os
import sys
import json
import argparse
import numpy as np
from PIL import Image

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from person import build_cohort          # noqa: E402
from inbody_html import render_html      # noqa: E402
from render import Renderer              # noqa: E402

CSS_W, CSS_H = 840, 1208
CANON = 2                                # 표준 좌표계 배율 (1680×2416)

# 필드 표시명 · 정답 키 · 값 형식
# ※ 내장지방단면적(VFA)은 산점도 위 마커라 값에 따라 상하좌우로 움직인다.
#    고정 좌표로는 읽을 수 없어 템플릿 대상에서 제외했다 — 템플릿 매칭의 명확한 한계.
FIELDS = {
    "ht":      ("신장",         "신장_cm",            "float"),
    "age":     ("연령",         "연령",               "int"),
    "tbw":     ("체수분",       "체수분_L",           "float"),
    "pro":     ("단백질",       "단백질_kg",          "float"),
    "min":     ("무기질",       "무기질_kg",          "float2"),
    "bfm":     ("체지방",       "체지방_kg",          "float"),
    "slm":     ("근육량",       "근육량_kg",          "float"),
    "ffm":     ("제지방량",     "제지방량_kg",        "float"),
    "wt":      ("체중",         "체중_kg",            "float"),
    "wt_bar":  ("체중(막대)",   "체중_kg",            "float"),
    "smm":     ("골격근량",     "골격근량_kg",        "float"),
    "bfm_bar": ("체지방량(막대)", "체지방_kg",        "float"),
    "bmi":     ("BMI",          "BMI",                "float"),
    "pbf":     ("체지방률",     "체지방률_pct",       "float"),
    "ecwr":    ("세포외수분비", "세포외수분비",       "float3"),
    "score":   ("인바디점수",   "인바디점수",         "int"),
    "idw":     ("적정체중",     "적정체중_kg",        "float"),
    "wctl":    ("체중조절",     "체중조절_kg",        "signed"),
    "fctl":    ("지방조절",     "지방조절_kg",        "signed"),
    "mctl":    ("근육조절",     "근육조절_kg",        "signed"),
    "icw":     ("세포내수분",   "세포내수분_L",       "float"),
    "ecw":     ("세포외수분",   "세포외수분_L",       "float"),
    "bmr":     ("기초대사량",   "기초대사량_kcal",    "int"),
    "smi":     ("SMI",          "SMI_kg_m2",          "float"),
    "pha":     ("위상각",       "위상각_deg",         "float"),
}

# 정렬용 앵커 — 값이 바뀌어도 항상 같은 자리에 있는 고정 요소.
# 페이지 상·중·하로 퍼뜨려야 정렬(스케일 추정)이 안정적이다.
ANCHOR_SEL = [
    ("logo",     ".logo"),               # 좌상단 InBody 로고
    ("rlogo",    ".rlogo"),              # 우상단 로고
    ("sec_bc",   ".col-l .sec:nth-of-type(1) .st"),   # 체성분분석 (상단)
    ("sec_ecw",  ".col-l .sec:nth-of-type(5) .st"),   # 세포외수분비분석 (중하단)
    ("sec_hist", ".col-l .sec:nth-of-type(6) .st"),   # 신체변화 (하단)
    ("foot",     ".foot"),               # 우하단 저작권 표기
]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="template_770s")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)

    p = build_cohort(per_class=1)[1]          # 아무 인물이나 (좌표는 값과 무관)
    html = render_html(p)

    r = Renderer(scale=CANON)
    ref_png = os.path.join(a.out, "reference.png")
    r.shot(html, ref_png, CSS_W, CSS_H)

    # DOM에서 각 값 요소의 바운딩박스를 읽는다
    page = r.browser.new_page(viewport={"width": CSS_W, "height": CSS_H},
                              device_scale_factor=1)
    page.set_content(html, wait_until="load")
    page.wait_for_timeout(150)
    boxes = page.evaluate("""() => {
        const out = {};
        document.querySelectorAll('[data-f]').forEach(el => {
            const b = el.getBoundingClientRect();
            // 막대그래프의 값은 값 크기에 따라 좌우로 움직인다.
            // 그런 필드는 '막대 전체'를 범위로 삼아야 한다.
            const bar = el.classList.contains('bval') ? el.parentElement : null;
            const p = bar ? bar.getBoundingClientRect() : null;
            out[el.getAttribute('data-f')] = {
                x: b.x, y: b.y, w: b.width, h: b.height,
                bar: p ? {x: p.x, y: p.y, w: p.width, h: p.height} : null
            };
        });
        return out;
    }""")
    anc_boxes = page.evaluate("""(sels) => {
        const out = {};
        for (const [name, sel] of sels) {
            const el = document.querySelector(sel);
            if (!el) continue;
            const b = el.getBoundingClientRect();
            out[name] = {x: b.x, y: b.y, w: b.width, h: b.height};
        }
        return out;
    }""", ANCHOR_SEL)
    page.close()
    r.close()

    # 우측 패널 값은 오른쪽에 단위가 붙고 값이 길어지면 왼쪽으로 자란다 → 왼쪽만 넓힌다
    RIGHT_PANEL = {"idw", "wctl", "fctl", "mctl", "icw", "ecw", "bmr", "smi", "pha"}
    # 값 길이가 고정이라 여유가 거의 필요 없는 필드
    TIGHT = {"ht": (4, 3), "age": (12, 12), "score": (16, 16)}

    rois = {}
    for fid, (label, gt_key, kind) in FIELDS.items():
        b = boxes.get(fid)
        if not b:
            print(f"  ! DOM에서 못 찾음: {fid}")
            continue

        if b.get("bar"):
            # 막대 값: 위치가 값에 따라 움직이므로 막대 전체를 범위로 잡는다.
            # 막대 안에는 숫자 외에 글자가 없어서 통째로 읽어도 안전하다.
            p = b["bar"]
            x0, y0 = p["x"] + 1, p["y"] - 1
            x1, y1 = p["x"] + p["w"] - 1, p["y"] + p["h"] + 1
            mode = "bar"
        else:
            if fid in TIGHT:
                pl, pr = TIGHT[fid]
            elif fid in RIGHT_PANEL:
                pl, pr = 34, 2          # 왼쪽으로 자람 · 오른쪽엔 단위(kg/L/kcal)
            else:
                pl, pr = 26, 26         # 표 안 값은 가운데 정렬 → 좌우 대칭
            x0, y0 = max(0, b["x"] - pl), max(0, b["y"] - 1)
            x1, y1 = min(CSS_W, b["x"] + b["w"] + pr), min(CSS_H, b["y"] + b["h"] + 1)
            mode = "cell"

        rois[fid] = {"label": label, "gt_key": gt_key, "kind": kind, "mode": mode,
                     "box": [round(x0 * CANON), round(y0 * CANON),
                             round(x1 * CANON), round(y1 * CANON)]}

    ref = np.array(Image.open(ref_png).convert("L"))
    H, W = ref.shape
    anchors = []
    for name, _sel in ANCHOR_SEL:
        b = anc_boxes.get(name)
        if not b or b["w"] < 8 or b["h"] < 6:
            print(f"  ! 앵커 못 찾음: {name}")
            continue
        x0 = int(max(0, b["x"] - 2) * CANON)
        y0 = int(max(0, b["y"] - 2) * CANON)
        x1 = int(min(CSS_W, b["x"] + b["w"] + 2) * CANON)
        y1 = int(min(CSS_H, b["y"] + b["h"] + 2) * CANON)
        patch = ref[y0:y1, x0:x1]
        if patch.size == 0 or patch.std() < 12:      # 밋밋한 패치는 매칭에 쓸모없다
            print(f"  ! 앵커 대비 부족, 제외: {name}")
            continue
        Image.fromarray(patch).save(os.path.join(a.out, f"anchor_{name}.png"))
        anchors.append({"name": name, "box": [x0, y0, x1, y1],
                        "patch": f"anchor_{name}.png"})

    spec = {"model": "InBody770S",
            "canonical_size": [CSS_W * CANON, CSS_H * CANON],
            "css_size": [CSS_W, CSS_H],
            "anchors": anchors, "fields": rois}
    with open(os.path.join(a.out, "template.json"), "w", encoding="utf-8") as f:
        json.dump(spec, f, ensure_ascii=False, indent=1)

    print(f"템플릿 저장: {a.out}/template.json")
    print(f"  필드 {len(rois)}개 · 앵커 {len(anchors)}개 · "
          f"표준 크기 {CSS_W*CANON}×{CSS_H*CANON}")


if __name__ == "__main__":
    main()
