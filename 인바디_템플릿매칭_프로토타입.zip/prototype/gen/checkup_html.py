# -*- coding: utf-8 -*-
"""일반건강검진 결과통보서 HTML 재현 (건강검진 실시기준 별지 6 기반)."""

FONT = "'Noto Sans CJK KR','Noto Sans KR',sans-serif"

CSS = """
*{margin:0;padding:0;box-sizing:border-box}
body{background:#fff}
.page{width:820px;height:1160px;background:#fff;font-family:%FONT%;color:#111;
      padding:26px 34px;position:relative;font-size:11.5px}
.title{text-align:center;font-size:20px;font-weight:800;letter-spacing:3px;
       padding:4px 0 3px;border-bottom:2.5px solid #111;margin-bottom:9px}
.sub{text-align:center;font-size:9.5px;color:#444;margin-top:-7px;margin-bottom:9px}
table{border-collapse:collapse;width:100%;table-layout:fixed}
td,th{border:1px solid #555;padding:2.5px 5px;font-size:10.5px;vertical-align:middle;height:22px}
th{background:#e8eaed;font-weight:700;text-align:center;font-size:10px}
.lb{background:#f2f3f5;font-weight:600;text-align:center;font-size:10px}
.ctr{text-align:center}.rgt{text-align:right}
.sec{font-size:12px;font-weight:800;margin:9px 0 3px;padding-left:2px;
     border-left:4px solid #111}
.jud{font-size:15px;font-weight:800;letter-spacing:1px}
.op{font-size:10.5px;line-height:1.5;padding:5px 6px;min-height:52px;vertical-align:top}
.ab{font-weight:700}
.sm{font-size:9px;color:#333}
.sign{margin-top:10px;text-align:right;font-size:11px;line-height:1.9}
.stamp{display:inline-block;width:46px;height:46px;border:2px solid #b03a3a;border-radius:50%;
       color:#b03a3a;font-size:9px;font-weight:700;text-align:center;line-height:1.15;
       padding-top:9px;margin-left:8px;vertical-align:middle;transform:rotate(-8deg)}
.foot{position:absolute;bottom:12px;left:34px;right:34px;font-size:8.5px;color:#555;
      border-top:1px solid #bbb;padding-top:4px}
"""

REF = {
    "신장": "-", "체중": "-",
    "체질량지수": "18.5~24.9",
    "허리둘레": "남 90 미만 / 여 85 미만",
    "시력": "-", "청력": "정상",
    "혈압": "120/80 미만",
    "요단백": "음성",
    "혈색소": "남 13~16.5 / 여 12~15.5",
    "공복혈당": "100 미만",
    "총콜레스테롤": "200 미만",
    "HDL콜레스테롤": "40 이상",
    "중성지방": "150 미만",
    "LDL콜레스테롤": "130 미만",
    "혈청크레아티닌": "1.5 이하",
    "e-GFR": "60 이상",
    "AST(SGOT)": "40 이하",
    "ALT(SGPT)": "35 이하",
    "감마지티피": "남 63 이하 / 여 35 이하",
}


def _row(name, unit, value, ref, judge):
    ab = "ab" if judge not in ("정상", "-", "") else ""
    return (f'<tr><td class="lb">{name}</td><td class="ctr sm">{unit}</td>'
            f'<td class="ctr {ab}" style="font-size:11.5px">{value}</td>'
            f'<td class="ctr sm">{ref}</td>'
            f'<td class="ctr {ab}">{judge}</td></tr>')


def render_html(p, c):
    f = c
    sx = "남" if p.sex == "M" else "여"
    jd = f.j

    def lvl_bp():
        return jd["고혈압"]

    # ── 계측검사
    meas = "".join([
        _row("신장", "cm", f"{f.height:.1f}", REF["신장"], "-"),
        _row("체중", "kg", f"{f.weight:.1f}", REF["체중"], "-"),
        _row("체질량지수", "kg/m²", f"{f.bmi:.1f}", REF["체질량지수"],
             jd["비만"] if jd["비만"] != "정상" else "정상"),
        _row("허리둘레", "cm", f"{f.waist:.1f}", REF["허리둘레"],
             "복부비만" if jd["복부비만"] == "해당" else "정상"),
        _row("시력(좌/우)", "", f"{f.vision[0]} / {f.vision[1]}", REF["시력"], "-"),
        _row("청력(좌/우)", "", f"{f.hearing[0]} / {f.hearing[1]}", REF["청력"],
             "정상" if f.hearing == ("정상", "정상") else "이상"),
        _row("혈압(수축기/이완기)", "mmHg", f"{f.sbp} / {f.dbp}", REF["혈압"], lvl_bp()),
    ])

    # ── 요·혈액검사
    ldl = f"{f.ldl}" if f.ldl is not None else "산출불가"
    blood = "".join([
        _row("요단백", "", f.urine, REF["요단백"], jd["요단백"]),
        _row("혈색소", "g/dL", f"{f.hb:.1f}", REF["혈색소"], jd["빈혈"]),
        _row("공복혈당", "mg/dL", f"{f.fbs}", REF["공복혈당"], jd["당뇨병"]),
        _row("총콜레스테롤", "mg/dL", f"{f.tc}", REF["총콜레스테롤"],
             "정상" if f.tc < 200 else ("경계" if f.tc < 240 else "질환의심")),
        _row("HDL콜레스테롤", "mg/dL", f"{f.hdl}", REF["HDL콜레스테롤"],
             "정상" if f.hdl >= 40 else "질환의심"),
        _row("중성지방", "mg/dL", f"{f.tg}", REF["중성지방"],
             "정상" if f.tg < 150 else ("경계" if f.tg < 200 else "질환의심")),
        _row("LDL콜레스테롤", "mg/dL", ldl, REF["LDL콜레스테롤"],
             "-" if f.ldl is None else
             ("정상" if f.ldl < 130 else ("경계" if f.ldl < 160 else "질환의심"))),
        _row("혈청크레아티닌", "mg/dL", f"{f.cr:.2f}", REF["혈청크레아티닌"],
             "정상" if f.cr <= 1.5 else "질환의심"),
        _row("신사구체여과율(e-GFR)", "mL/min/1.73㎡", f"{f.egfr}", REF["e-GFR"],
             "정상" if f.egfr >= 60 else "질환의심"),
        _row("AST(SGOT)", "IU/L", f"{f.ast}", REF["AST(SGOT)"],
             "정상" if f.ast <= 40 else ("경계" if f.ast <= 50 else "질환의심")),
        _row("ALT(SGPT)", "IU/L", f"{f.alt}", REF["ALT(SGPT)"],
             "정상" if f.alt <= 35 else ("경계" if f.alt <= 45 else "질환의심")),
        _row("감마지티피(γ-GTP)", "IU/L", f"{f.ggt}", REF["감마지티피"],
             jd["간장질환"] if (f.ast > 40 or f.alt > 35) else
             ("정상" if f.ggt <= (63 if p.sex == "M" else 35) else "경계")),
    ])

    # ── 질환별 판정
    order = ["고혈압", "당뇨병", "이상지질혈증", "신장질환", "간장질환", "빈혈", "비만"]
    dz_h = "".join(f"<th>{k}</th>" for k in order)
    dz_v = "".join(
        f'<td class="ctr {"ab" if jd[k] not in ("정상",) else ""}">{jd[k]}</td>'
        for k in order)

    return f"""<!doctype html><html lang="ko"><head><meta charset="utf-8">
<style>{CSS.replace('%FONT%', FONT)}</style></head><body><div class="page">

<div class="title">일반건강검진 결과통보서</div>
<div class="sub">「건강검진기본법」제10조 및 「건강검진 실시기준」 별지 제6호서식</div>

<table>
 <colgroup><col style="width:72px"><col style="width:150px"><col style="width:72px">
  <col style="width:130px"><col style="width:72px"><col></colgroup>
 <tr><td class="lb">성명</td><td class="ctr" style="font-weight:700">{p.name}</td>
     <td class="lb">생년월일</td><td class="ctr">{p.birth.strftime('%Y. %m. %d.')}</td>
     <td class="lb">성별</td><td class="ctr">{sx}</td></tr>
 <tr><td class="lb">검진일</td><td class="ctr">{f.exam_date.strftime('%Y. %m. %d.')}</td>
     <td class="lb">판정일</td><td class="ctr">{f.judge_date.strftime('%Y. %m. %d.')}</td>
     <td class="lb">연령</td><td class="ctr">만 {p.age}세</td></tr>
 <tr><td class="lb">검진기관</td><td class="ctr" colspan="3">{f.org}</td>
     <td class="lb">기관기호</td><td class="ctr">{f.org_code}</td></tr>
</table>

<div class="sec">판정 및 조치사항</div>
<table>
 <colgroup><col style="width:82px"><col style="width:170px"><col style="width:82px"><col></colgroup>
 <tr><td class="lb">종합판정</td>
     <td class="ctr jud">{f.overall}</td>
     <td class="lb">판정 상세</td>
     <td class="ctr ab">{f.overall_detail}</td></tr>
 <tr><td class="lb">종합소견 및<br>조치사항</td>
     <td class="op" colspan="3">{f.opinion}</td></tr>
</table>

<div class="sec">계측검사</div>
<table>
 <colgroup><col style="width:168px"><col style="width:92px"><col style="width:110px">
  <col style="width:180px"><col></colgroup>
 <tr><th>검사항목</th><th>단위</th><th>검사결과</th><th>참고치</th><th>판정</th></tr>
 {meas}
</table>

<div class="sec">요검사 · 혈액검사</div>
<table>
 <colgroup><col style="width:168px"><col style="width:92px"><col style="width:110px">
  <col style="width:180px"><col></colgroup>
 <tr><th>검사항목</th><th>단위</th><th>검사결과</th><th>참고치</th><th>판정</th></tr>
 {blood}
</table>

<div class="sec">영상검사</div>
<table>
 <colgroup><col style="width:168px"><col></colgroup>
 <tr><td class="lb">흉부방사선검사</td>
     <td class="{'ab' if f.xray != '정상' else ''}" style="padding-left:8px">{f.xray}</td></tr>
</table>

<div class="sec">질환별 판정</div>
<table><tr>{dz_h}</tr><tr>{dz_v}</tr></table>

<div class="sec">생활습관</div>
<table>
 <colgroup><col style="width:82px"><col><col style="width:82px"><col>
  <col style="width:82px"><col></colgroup>
 <tr><td class="lb">흡연</td><td class="ctr">{f.smoke}</td>
     <td class="lb">음주</td><td class="ctr">{f.drink}</td>
     <td class="lb">신체활동</td><td class="ctr">{f.exercise}</td></tr>
</table>

<div class="sign">
  판정의사 &nbsp; <b>{f.doctor}</b> &nbsp;(서명 또는 인)&nbsp;&nbsp;
  면허번호 제 <b>{f.lic}</b> 호
  <span class="stamp">{f.org[:2]}<br>검진</span>
</div>

<div class="foot">
 ※ 본 결과는 「건강검진 실시기준」 별표 4의 판정기준에 따라 판정되었습니다.
 판정이 '질환의심'인 경우 가까운 의료기관에서 2차 검진 또는 진료를 받으시기 바랍니다.
 검사 결과는 검진 당시의 상태를 나타내며, 확진을 대신하지 않습니다.
</div>
</div></body></html>"""
