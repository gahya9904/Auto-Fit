# -*- coding: utf-8 -*-
"""
인바디 결과지 템플릿 매칭 추출기 (프로토타입).

전제: 인바디 결과지는 기기 모델별로 인쇄 위치가 고정이다.
     따라서 '어디에 무엇이 있는지'를 알고 있으면 AI 모델 없이 값을 읽을 수 있다.

처리 순서
  ① 종이 영역 검출   배경이 있으면 밝기로, 흰 배경이면 잉크 범위로
  ② 원근·회전 보정   네 꼭짓점을 표준 직사각형으로 펴기
  ③ 앵커 정밀 정렬   로고·섹션제목 등 고정 요소를 찾아 잔여 오차 보정
  ④ 필드 크롭 + 판독 정해진 좌표를 잘라 숫자만 인식
  ⑤ 교차검증        crosscheck 규칙으로 앞뒤가 맞는지 확인

사용:
    from inbody_template import InBodyExtractor
    ex = InBodyExtractor("template_770s")
    result = ex.extract("photo.jpg")
"""
import os
import re
import json
import cv2
import numpy as np
import pytesseract


# ────────────────────────────────────────────── 기하 유틸
def order_quad(pts):
    """네 점을 좌상-우상-우하-좌하 순으로 정렬."""
    p = np.asarray(pts, np.float32).reshape(4, 2)
    s = p.sum(1)
    d = (p[:, 1] - p[:, 0])
    return np.float32([p[np.argmin(s)], p[np.argmin(d)],
                       p[np.argmax(s)], p[np.argmax(d)]])


def page_candidates(bgr):
    """
    종이 영역 후보를 여러 개 만든다.

    배경 유무를 미리 '판단'하려 하면 밝은 색 책상에서 틀린다.
    대신 후보를 모두 만들어 두고, 실제로 앵커가 가장 잘 맞는 것을 고른다.
    (추측하지 말고 측정한다)
    """
    h, w = bgr.shape[:2]
    gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
    out = []

    # A) 밝은 영역 = 종이 (배경이 찍힌 사진)
    blur = cv2.GaussianBlur(gray, (7, 7), 0)
    _, th = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    th = cv2.morphologyEx(th, cv2.MORPH_CLOSE,
                          cv2.getStructuringElement(cv2.MORPH_RECT, (25, 25)))
    cnts, _ = cv2.findContours(th, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if cnts:
        c = max(cnts, key=cv2.contourArea)
        if cv2.contourArea(c) > 0.20 * h * w:
            peri = cv2.arcLength(c, True)
            for eps in (0.02, 0.03, 0.04):
                ap = cv2.approxPolyDP(c, eps * peri, True)
                if len(ap) == 4:
                    out.append(("quad", order_quad(ap)))
                    break
            out.append(("minrect", order_quad(cv2.boxPoints(cv2.minAreaRect(c)))))

    # B) 잉크가 찍힌 범위 = 종이 안쪽 (흰 배경 사진)
    ink = ((gray < 200).astype(np.uint8)) * 255
    ink = cv2.morphologyEx(ink, cv2.MORPH_CLOSE,
                           cv2.getStructuringElement(cv2.MORPH_RECT, (15, 15)))
    pts = cv2.findNonZero(ink)
    if pts is not None:
        box = order_quad(cv2.boxPoints(cv2.minAreaRect(pts)))
        ctr = box.mean(axis=0)
        out.append(("ink", ctr + (box - ctr) * np.float32([1.045, 1.020])))

    # C) 최후 수단 — 화면 전체
    out.append(("full", np.float32([[0, 0], [w, 0], [w, h], [0, h]])))
    return out


def find_page(bgr):
    """(구버전 호환) 후보 중 첫 번째를 반환."""
    c = page_candidates(bgr)
    return c[0][1], c[0][0]


def _find_page_legacy(bgr):
    """종이 영역의 네 꼭짓점을 찾는다. (quad, 사용한 방법) 반환."""
    h, w = bgr.shape[:2]
    gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)

    # 테두리 밝기로 '배경이 찍혀 있는지' 판단
    bw = max(2, int(min(h, w) * 0.03))
    frame = np.concatenate([gray[:bw].ravel(), gray[-bw:].ravel(),
                            gray[:, :bw].ravel(), gray[:, -bw:].ravel()])
    has_bg = np.median(frame) < 205

    if has_bg:
        blur = cv2.GaussianBlur(gray, (7, 7), 0)
        _, th = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        k = cv2.getStructuringElement(cv2.MORPH_RECT, (25, 25))
        th = cv2.morphologyEx(th, cv2.MORPH_CLOSE, k)
        cnts, _ = cv2.findContours(th, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if cnts:
            c = max(cnts, key=cv2.contourArea)
            if cv2.contourArea(c) > 0.20 * h * w:
                peri = cv2.arcLength(c, True)
                for eps in (0.02, 0.03, 0.04, 0.015, 0.06):
                    ap = cv2.approxPolyDP(c, eps * peri, True)
                    if len(ap) == 4:
                        return order_quad(ap), "quad"
                return order_quad(cv2.boxPoints(cv2.minAreaRect(c))), "minrect"

    # 흰 배경 — 종이 경계가 보이지 않으므로 잉크가 찍힌 범위를 쓴다
    ink = ((gray < 200).astype(np.uint8)) * 255
    ink = cv2.morphologyEx(ink, cv2.MORPH_CLOSE,
                           cv2.getStructuringElement(cv2.MORPH_RECT, (15, 15)))
    pts = cv2.findNonZero(ink)
    if pts is None:
        return np.float32([[0, 0], [w, 0], [w, h], [0, h]]), "full"
    box = order_quad(cv2.boxPoints(cv2.minAreaRect(pts)))
    # 잉크 범위는 종이 안쪽 — 인쇄 여백만큼 바깥으로 넓힌다
    ctr = box.mean(axis=0)
    box = ctr + (box - ctr) * np.float32([1.045, 1.020])
    return box, "ink"


def warp(bgr, quad, size):
    W, H = size
    dst = np.float32([[0, 0], [W, 0], [W, H], [0, H]])
    M = cv2.getPerspectiveTransform(np.float32(quad), dst)
    return cv2.warpPerspective(bgr, M, (W, H), flags=cv2.INTER_CUBIC,
                               borderMode=cv2.BORDER_CONSTANT,
                               borderValue=(255, 255, 255))


# ────────────────────────────────────────────── 추출기
class InBodyExtractor:
    def __init__(self, tpl_dir, min_anchor_score=0.25, search_ratio=0.07, passes=2):
        self.dir = tpl_dir
        with open(os.path.join(tpl_dir, "template.json"), encoding="utf-8") as f:
            self.tpl = json.load(f)
        self.W, self.H = self.tpl["canonical_size"]
        self.min_score = min_anchor_score
        self.search = search_ratio
        self.passes = passes
        self.anchors = []
        for a in self.tpl["anchors"]:
            patch = cv2.imread(os.path.join(tpl_dir, a["patch"]), cv2.IMREAD_GRAYSCALE)
            if patch is not None:
                self.anchors.append((a["name"], a["box"], patch))

    # ── ③ 앵커로 잔여 오차 보정
    def _match_anchors(self, canon):
        """각 앵커를 찾아 (관측 중심, 기준 중심, 점수) 목록을 만든다."""
        g = cv2.cvtColor(canon, cv2.COLOR_BGR2GRAY)
        g = cv2.createCLAHE(2.0, (8, 8)).apply(g)
        src, dst, scores = [], [], []
        m = int(max(self.W, self.H) * self.search)
        for _name, (x0, y0, x1, y1), patch in self.anchors:
            ph, pw = patch.shape
            sx0, sy0 = max(0, x0 - m), max(0, y0 - m)
            sx1, sy1 = min(self.W, x1 + m), min(self.H, y1 + m)
            win = g[sy0:sy1, sx0:sx1]
            if win.shape[0] < ph or win.shape[1] < pw:
                continue
            # 흐린 사진에서는 선명한 기준 패치가 잘 안 맞는다.
            # 양쪽에 같은 블러를 걸어 선명도를 맞춘 뒤 가장 잘 맞는 값을 쓴다.
            best_s, best_loc = -1.0, None
            for sigma in (0, 1.2, 2.6):
                pp = patch if sigma == 0 else cv2.GaussianBlur(patch, (0, 0), sigma)
                ww = win if sigma == 0 else cv2.GaussianBlur(win, (0, 0), sigma)
                res = cv2.matchTemplate(ww, pp, cv2.TM_CCOEFF_NORMED)
                _, mx, _, loc = cv2.minMaxLoc(res)
                if mx > best_s:
                    best_s, best_loc = mx, loc
            if best_s < self.min_score:
                continue
            src.append([sx0 + best_loc[0] + pw / 2, sy0 + best_loc[1] + ph / 2])
            dst.append([x0 + pw / 2, y0 + ph / 2])
            scores.append(best_s)
        return src, dst, scores

    @staticmethod
    def _sane(M):
        """추정된 변환이 상식적인 범위인지 확인. 앵커를 잘못 잡으면 화면이 망가진다."""
        if M is None:
            return False
        sx = float(np.hypot(M[0, 0], M[1, 0]))
        sy = float(np.hypot(M[0, 1], M[1, 1]))
        rot = abs(float(np.degrees(np.arctan2(M[1, 0], M[0, 0]))))
        return (0.85 < sx < 1.18) and (0.85 < sy < 1.18) and rot < 12

    def refine(self, canon):
        src, dst, scores = self._match_anchors(canon)
        best_n = len(src)
        best_s = float(np.mean(scores)) if scores else 0.0
        for _ in range(self.passes):
            if len(src) < 2:
                break
            if len(src) >= 3:
                # 앵커가 3개 이상이면 가로·세로 배율이 다른 경우까지 보정
                M, _ = cv2.estimateAffine2D(np.float32(src), np.float32(dst),
                                            method=cv2.RANSAC,
                                            ransacReprojThreshold=10)
            else:
                M, _ = cv2.estimateAffinePartial2D(np.float32(src), np.float32(dst),
                                                   method=cv2.RANSAC,
                                                   ransacReprojThreshold=10)
            if not self._sane(M):
                break
            cand = cv2.warpAffine(canon, M, (self.W, self.H), flags=cv2.INTER_CUBIC,
                                  borderMode=cv2.BORDER_CONSTANT,
                                  borderValue=(255, 255, 255))
            s2, d2, sc2 = self._match_anchors(cand)
            n2 = len(s2)
            m2 = float(np.mean(sc2)) if sc2 else 0.0
            # 보정 후가 더 나쁘면 되돌린다 (앵커 오검출로 망가지는 것 방지)
            if n2 < best_n or (n2 == best_n and m2 < best_s - 0.02):
                break
            canon, best_n, best_s = cand, n2, m2
            src, dst, scores = s2, d2, sc2
            if float(np.hypot(M[0, 2], M[1, 2])) < 1.5:
                break
        return canon, best_n, best_s

    # ── ④ 필드 한 칸 읽기
    @staticmethod
    def _isolate_text(th):
        """이진 크롭에서 '가운데 글자줄'만 남긴다.

        인바디 결과지는 값 주변에 표 테두리선, 바로 아래 참고범위(7.0~8.6),
        막대그래프의 검은 채움 블록이 붙어 있다. 이것들이 숫자로 오인식되어
        8.4 → 84.0 같은 오류를 만든다. 연결성분 단위로 걸러낸다.
        """
        inv = 255 - th                                   # 글자를 흰색으로
        n, lab, stats, _ = cv2.connectedComponentsWithStats(inv, 8)
        H, W = th.shape
        comps = []
        for i in range(1, n):
            x, y, w, h, a = stats[i]
            if a < 6:
                continue
            if w >= 0.90 * W and h <= 0.15 * H:          # 가로 테두리선
                continue
            if h >= 0.90 * H and w <= 0.15 * W:          # 세로 테두리선
                continue
            if w >= 0.28 * W and h >= 0.70 * H and a >= 0.55 * w * h:
                continue                                  # 막대의 검은 채움 블록
            comps.append((x, y, w, h, i))
        if not comps:
            return th
        hmax = max(c[3] for c in comps)
        core = [c for c in comps if c[3] >= 0.55 * hmax] or comps
        ytop = min(c[1] for c in core)
        ybot = max(c[1] + c[3] for c in core)
        keep = np.zeros_like(inv)
        for x, y, w, h, i in comps:
            cy = y + h / 2.0
            if ytop - 0.30 * hmax <= cy <= ybot + 0.30 * hmax and h <= 1.45 * hmax:
                keep[lab == i] = 255                      # 소수점도 여기서 살아남는다
        if not keep.any():
            return th
        return 255 - keep

    @staticmethod
    def _prep(crop, upscale, mode):
        c = cv2.resize(crop, None, fx=upscale, fy=upscale,
                       interpolation=cv2.INTER_CUBIC)
        # 언샤프 마스킹 — 저화질/흐린 사진에서 숫자 획을 살린다
        blur = cv2.GaussianBlur(c, (0, 0), max(1.0, upscale * 0.6))
        c = cv2.addWeighted(c, 1.7, blur, -0.7, 0)
        c = cv2.createCLAHE(2.5, (8, 8)).apply(c)
        _, t = cv2.threshold(c, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        if t.mean() < 127:
            t = 255 - t
        t = InBodyExtractor._isolate_text(t)
        return cv2.copyMakeBorder(t, 16, 16, 16, 16, cv2.BORDER_CONSTANT, value=255)

    @classmethod
    def _ocr(cls, img, wl):
        # 크롭이 비었거나 단색이면 테서랙트가 죽는다(SIGFPE). 미리 걸러낸다.
        if img is None or img.size == 0 or min(img.shape[:2]) < 8:
            return "", 0.0
        if float(img.std()) < 3.0:
            return "", 0.0
        cfg = f"--oem 1 --psm 7 -c tessedit_char_whitelist={wl}"
        try:
            d = pytesseract.image_to_data(img, lang="eng", config=cfg,
                                          output_type=pytesseract.Output.DICT)
        except Exception:
            return "", 0.0
        toks, confs = [], []
        for t, c in zip(d["text"], d["conf"]):
            t = t.strip()
            if t and float(c) >= 0:
                toks.append(t)
                confs.append(float(c))
        return " ".join(toks), (float(np.mean(confs)) if confs else 0.0)

    @classmethod
    def read_cell(cls, gray, box, kind, upscale=4, mode="cell"):
        x0, y0, x1, y1 = box
        crop = gray[max(0, y0):y1, max(0, x0):x1]
        if crop.size == 0:
            return None, ""
        wl = "0123456789" if kind == "int" else "0123456789.+-"
        if mode == "bar":
            # 막대 값은 막대 밖(검은 글자)일 수도, 채움 안(흰 글자)일 수도 있다.
            # 양쪽 극성을 다 시도해 신뢰도가 높은 쪽을 쓴다.
            best = (None, "", -1.0)
            for c in (crop, 255 - crop):
                for up in (upscale, upscale + 2):
                    txt, conf = cls._ocr(cls._prep(c, up, "otsu"), wl)
                    val = parse_num(txt, kind)
                    if val is not None and conf > best[2]:
                        best = (val, txt.strip(), conf)
                    if best[0] is not None and best[2] >= 80:
                        return best[0], best[1]
            return best[0], best[1]
        if crop.mean() < 115:                     # 검은 막대 위 흰 글자 → 반전
            crop = 255 - crop
        # 기본 변형으로 먼저 시도하고, 결과가 없거나 신뢰도가 낮을 때만 대안을 더 본다.
        best = (None, "", -1.0)
        for up, mode in ((upscale, "otsu"), (upscale + 3, "otsu")):
            txt, conf = cls._ocr(cls._prep(crop, up, mode), wl)
            val = parse_num(txt, kind)
            if val is not None and conf > best[2]:
                best = (val, txt.strip(), conf)
            if best[0] is not None and best[2] >= 75:
                break
        return best[0], best[1]

    # ── 전체 파이프라인
    def extract(self, path, debug_dir=None):
        bgr = cv2.imread(path)
        if bgr is None:
            raise FileNotFoundError(path)
        best = None
        for name, quad in page_candidates(bgr):
            cand = warp(bgr, quad, (self.W, self.H))
            cand, n, sc = self.refine(cand)
            rank = n + 3.0 * sc                 # 앵커 수보다 매칭 품질에 가중
            if best is None or rank > best[0]:
                best = (rank, cand, name, n, sc)
        _rank, canon, method, n_anc, anc_score = best
        gray = cv2.cvtColor(canon, cv2.COLOR_BGR2GRAY)

        values, raw = {}, {}
        for fid, spec in self.tpl["fields"].items():
            v, t = self.read_cell(gray, spec["box"], spec["kind"],
                                  mode=spec.get("mode", "cell"))
            values[fid] = v
            raw[fid] = t

        if debug_dir:
            os.makedirs(debug_dir, exist_ok=True)
            vis = canon.copy()
            for fid, spec in self.tpl["fields"].items():
                x0, y0, x1, y1 = spec["box"]
                ok = values[fid] is not None
                cv2.rectangle(vis, (x0, y0), (x1, y1),
                              (0, 170, 0) if ok else (0, 0, 230), 3)
            for _n, (x0, y0, x1, y1), _p in self.anchors:
                cv2.rectangle(vis, (x0, y0), (x1, y1), (230, 120, 0), 3)
            cv2.imwrite(os.path.join(
                debug_dir, os.path.basename(path).replace(".jpg", "_vis.jpg")), vis)

        return {"values": values, "raw": raw, "detect_method": method,
                "anchors_matched": n_anc, "anchor_score": round(anc_score, 3)}

    # 정답 키 기준 dict로 변환 (crosscheck 입력용)
    def to_gt_keys(self, values):
        out = {}
        for fid, spec in self.tpl["fields"].items():
            v = values.get(fid)
            if v is None:
                continue
            out.setdefault(spec["gt_key"], v)
        return out


def parse_num(txt, kind):
    t = txt.replace(" ", "").replace(",", ".").replace("|", "1")
    m = re.search(r"[+-]?\d+(?:\.\d+)?", t)
    if not m:
        return None
    try:
        v = float(m.group())
    except ValueError:
        return None
    return int(round(v)) if kind == "int" else v


def is_correct(pred, gt, kind):
    if pred is None or gt is None:
        return False
    tol = {"int": 0.5, "float": 0.051, "float2": 0.0051,
           "float3": 0.00051, "signed": 0.051}.get(kind, 0.051)
    return abs(float(pred) - float(gt)) < tol
