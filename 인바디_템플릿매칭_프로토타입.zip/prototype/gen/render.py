# -*- coding: utf-8 -*-
"""HTML → PNG 렌더 (Chromium)."""
import os
from playwright.sync_api import sync_playwright


class Renderer:
    def __init__(self, scale=1.7):
        self.scale = scale
        self._pw = sync_playwright().start()
        self.browser = self._pw.chromium.launch(
            args=["--no-sandbox", "--disable-dev-shm-usage",
                  "--font-render-hinting=none", "--disable-lcd-text"])

    def shot(self, html, out_path, width, height):
        page = self.browser.new_page(
            viewport={"width": width, "height": height},
            device_scale_factor=self.scale)
        page.set_content(html, wait_until="load")
        page.wait_for_timeout(120)
        os.makedirs(os.path.dirname(out_path), exist_ok=True)
        page.screenshot(path=out_path, clip={"x": 0, "y": 0,
                                             "width": width, "height": height})
        page.close()
        return out_path

    def close(self):
        self.browser.close()
        self._pw.stop()
