# -*- coding: utf-8 -*-
"""인바디 템플릿 매칭 정확도 평가 — 노이즈 프리셋별·필드별 + 교차검증 효과."""
import os, sys, json, csv, argparse
from collections import defaultdict
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from inbody_template import InBodyExtractor, is_correct   # noqa: E402
from crosscheck import check_inbody                        # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", default="dataset")
    ap.add_argument("--template", default="template_770s")
    ap.add_argument("--out", default="out/template_eval.json")
    ap.add_argument("--limit", type=int, default=0)
    a = ap.parse_args()

    gt = json.load(open(os.path.join(a.dataset, "labels", "ground_truth.json"),
                        encoding="utf-8"))
    recs = [r for r in gt["records"] if r["doc_type"] == "inbody"]
    if a.limit:
        recs = recs[:a.limit]
    ex = InBodyExtractor(a.template)

    by_preset = defaultdict(lambda: [0, 0])
    by_field = defaultdict(lambda: [0, 0])
    cc_stats = defaultdict(lambda: {"pass": 0, "flag": 0,
                                    "pass_ok": 0, "pass_tot": 0})
    rows = []

    for i, r in enumerate(recs, 1):
        res = ex.extract(os.path.join(a.dataset, r["image"]))
        f, pre = r["fields"], r["noise_preset"]
        ok = tot = 0
        for fid, spec in ex.tpl["fields"].items():
            c = is_correct(res["values"][fid], f.get(spec["gt_key"]), spec["kind"])
            ok += c; tot += 1
            by_field[spec["label"]][0] += c
            by_field[spec["label"]][1] += 1
        by_preset[pre][0] += ok
        by_preset[pre][1] += tot

        # 교차검증: 정답을 몰라도 오인식을 걸러낼 수 있는가
        viol = check_inbody(ex.to_gt_keys(res["values"]))
        st = cc_stats[pre]
        if viol:
            st["flag"] += 1
        else:
            st["pass"] += 1
            st["pass_ok"] += ok
            st["pass_tot"] += tot
        rows.append({"image": r["image"], "preset": pre,
                     "anchors": res["anchors_matched"],
                     "anchor_score": res["anchor_score"],
                     "fields_ok": ok, "fields_total": tot,
                     "crosscheck_violations": len(viol)})
        if i % 20 == 0:
            print(f"  {i}/{len(recs)} …", flush=True)

    print("\n프리셋별 필드 정확도")
    print("-" * 62)
    ORDER = ["clean", "n1_tilt_light", "n2_shadow_persp", "n3_fold_crumple",
             "n4_lowres_blur", "n5_heavy_mixed"]
    for p in ORDER:
        o, t = by_preset[p]
        s = cc_stats[p]
        n = s["pass"] + s["flag"]
        pa = s["pass_ok"] / s["pass_tot"] * 100 if s["pass_tot"] else 0
        print(f"  {p:17s} {o/t*100:5.1f}%   검증통과 {s['pass']:2d}/{n} "
              f"→ 통과분 정확도 {pa:5.1f}%")

    print("\n필드별 정확도 (전 프리셋)")
    print("-" * 62)
    for k, (o, t) in sorted(by_field.items(), key=lambda x: x[1][0] / max(1, x[1][1])):
        print(f"  {k:16s} {o/t*100:5.1f}%  ({o}/{t})")

    os.makedirs(os.path.dirname(a.out), exist_ok=True)
    json.dump({"per_preset": {k: {"ok": v[0], "total": v[1],
                                  "acc": round(v[0]/v[1]*100, 1)}
                              for k, v in by_preset.items()},
               "per_field": {k: {"ok": v[0], "total": v[1],
                                 "acc": round(v[0]/v[1]*100, 1)}
                             for k, v in by_field.items()},
               "crosscheck": {k: dict(v) for k, v in cc_stats.items()},
               "rows": rows}, open(a.out, "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    with open(a.out.replace(".json", ".csv"), "w", encoding="utf-8-sig",
              newline="") as fp:
        w = csv.DictWriter(fp, fieldnames=list(rows[0].keys())); w.writeheader()
        w.writerows(rows)
    print(f"\n→ {a.out}")


if __name__ == "__main__":
    main()
